﻿using MCBAAdminWebsite.Models;
using System.ComponentModel.DataAnnotations;
using Xunit;

namespace MCBAAdminWebsite.Tests.Models
{
    public class LoginTests
    {
        [Theory]
        [InlineData("", "Password")]
        [InlineData("Username", "")]
        [InlineData("Username1234567890", "Password1234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890")]
        public void UsernameAndPassword_Validation(string username, string password)
        {
            // Arrange
            var login = new Login
            {
                Username = username,
                Password = password
            };

            var validationContext = new ValidationContext(login, null, null);
            var validationResults = new System.Collections.Generic.List<ValidationResult>();

            // Act
            bool isValid = Validator.TryValidateObject(login, validationContext, validationResults, true);

            // Assert
            Assert.False(isValid);
        }

    }
}
