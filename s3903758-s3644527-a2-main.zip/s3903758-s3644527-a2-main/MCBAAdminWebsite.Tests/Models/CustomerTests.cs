﻿using System.Collections.Generic;
using MCBAAdminWebsite.Models;
using Xunit;

namespace MCBAAdminWebsite.Tests.Models
{
    public class CustomerTests
    {
        [Theory]
        [InlineData("ACT", "Australian Capital Territory")]
        [InlineData("NSW", "New South Wales")]
        [InlineData("NT", "Northern Territory")]
        [InlineData("QLD", "Queensland")]
        [InlineData("SA", "South Australia")]
        [InlineData("TAS", "Tasmania")]
        [InlineData("WA", "Western Australia")]
        [InlineData("VIC", "Victoria")]
        public void StateMap_Contains_ValidData(string stateCode, string expectedStateName)
        {
            // Arrange
            var stateMap = Customer.StateMap;

            // Act
            bool containsStateCode = stateMap.ContainsKey(stateCode);
            string actualStateName = stateMap[stateCode];

            // Assert
            Assert.True(containsStateCode);
            Assert.Equal(expectedStateName, actualStateName);
        }

    }
}
