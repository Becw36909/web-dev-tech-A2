﻿using System;
using System.Collections.Generic;
using MCBAAdminWebsite.Models;
using Xunit;

namespace MCBAAdminWebsite.Tests.Models
{
    public class BillpayTests
    {
        [Theory]
        [InlineData(State.Blocked)]
        public void GetBlockedState_ReturnsBlocked(State expectedState)
        {
            // Act
            var blockedState = Billpay.GetBlockedState();

            // Assert
            Assert.Equal(expectedState, blockedState);
        }

        [Theory]
        [InlineData("O", "One-Off")]
        [InlineData("M", "Monthly")]
        public void GetBillPayPeriod_ReturnsCorrectValue(string period, string expectedValue)
        {
            // Arrange
            var billPay = new Billpay { Period = period };

            // Act
            var actualValue = billPay.GetBillPayPeriod();

            // Assert
            Assert.Equal(expectedValue, actualValue);
        }

    }
}
