﻿using MCBAAdminWebsite.Models;
using Xunit;

namespace MCBAAdminWebsite.Tests.Models
{
    public class ErrorViewModelTests
    {
        [Theory]
        [InlineData(null, false)]
        [InlineData("", false)]
        [InlineData("RequestIdValue", true)]
        public void ShowRequestId_ReturnsCorrectValue(string requestId, bool expectedValue)
        {
            // Arrange
            var errorViewModel = new ErrorViewModel { RequestId = requestId };

            // Act
            var actualValue = errorViewModel.ShowRequestId;

            // Assert
            Assert.Equal(expectedValue, actualValue);
        }
    }
}
