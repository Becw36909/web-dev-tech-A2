﻿using Microsoft.AspNetCore.Mvc.ViewFeatures;
using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;

namespace MCBAAdminWebsite.Tests.Data
{
    public class MockTempData : ITempDataDictionary
    {
        private readonly Dictionary<string, object> _data = new Dictionary<string, object>();

        public object this[string key]
        {
            get => _data.ContainsKey(key) ? _data[key] : null;
            set => _data[key] = value;
        }

        public ICollection<string> Keys => _data.Keys;

        public ICollection<object> Values => _data.Values;

        public int Count => _data.Count;

        public bool IsReadOnly => throw new NotImplementedException();

        public bool ContainsKey(string key) => _data.ContainsKey(key);

        public void Add(string key, object value) => _data.Add(key, value);

        public bool Remove(string key) => _data.Remove(key);

        public void Clear() => _data.Clear();

        public void Load()
        {
            // For testing, this method can be empty as we're using an in-memory dictionary
        }

        public void Keep()
        {
            // For testing, this method can be empty as we're using an in-memory dictionary
        }

        public void Save()
        {
            // For testing, this method can be empty as we're using an in-memory dictionary
        }

        public IEnumerator<KeyValuePair<string, object>> GetEnumerator()
        {
            return _data.GetEnumerator();
        }

        System.Collections.IEnumerator System.Collections.IEnumerable.GetEnumerator()
        {
            return GetEnumerator();
        }

        public void Keep(string key)
        {
            throw new NotImplementedException();
        }

        public object? Peek(string key)
        {
            throw new NotImplementedException();
        }

        public bool TryGetValue(string key, [MaybeNullWhen(false)] out object? value)
        {
            throw new NotImplementedException();
        }

        public void Add(KeyValuePair<string, object?> item)
        {
            throw new NotImplementedException();
        }

        public bool Contains(KeyValuePair<string, object?> item)
        {
            throw new NotImplementedException();
        }

        public void CopyTo(KeyValuePair<string, object?>[] array, int arrayIndex)
        {
            throw new NotImplementedException();
        }

        public bool Remove(KeyValuePair<string, object?> item)
        {
            throw new NotImplementedException();
        }
    }
}
