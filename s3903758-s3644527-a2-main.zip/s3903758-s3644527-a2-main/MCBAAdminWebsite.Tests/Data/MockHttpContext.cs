﻿using MCBAAdminWebsite.Utilities.Session;
using Microsoft.AspNetCore.Http;

namespace MCBAAdminWebsite.Tests.Data
{
    public class MockHttpContext
    {

        public static HttpContext Create()
        {
            HttpContext HttpContext = new DefaultHttpContext();
            HttpContext.Session = new MockSession();

            return HttpContext;
        }

        public static HttpContext Create(string AdminName)
        {
            HttpContext HttpContext = new DefaultHttpContext();
            HttpContext.Session = new MockSession();
            HttpContext.Session.SetAdminName("admin");


            return HttpContext;
        }

    }
}
