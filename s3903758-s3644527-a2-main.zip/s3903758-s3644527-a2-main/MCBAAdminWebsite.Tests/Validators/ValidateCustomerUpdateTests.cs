﻿using MCBAAdminWebsite.Models;
using MCBAAdminWebsite.ViewModels;
using MCBAAdminWebsite.Validators;
using Microsoft.AspNetCore.Mvc.ModelBinding;
using Xunit;

namespace MCBAAdminWebsite.Tests.Validators;

public class ValidateCustomerUpdateTests
{
    [Theory]
    [InlineData("InvalidName12345678901234567890123456789012345678901234567890")]
    [InlineData("ValidName")]
    // Add more invalid and valid test cases as needed
    public void Validate_CustomerUpdate_Name_InvalidInputs_ReturnsFalse(string name)
    {
        // Arrange
        var viewModel = new CustomerEditViewModel
        {
            Customer = new Customer()
        };

        viewModel.Customer.Name = name;

        var modelState = new ModelStateDictionary();

        // Act
        var result = ValidateCustomerUpdate.Validate(viewModel, modelState);

        // Assert
        if (name != null && (name.Length <= 0 || name.Length > 50))
            Assert.Contains(nameof(viewModel.Customer.Name), modelState.Keys);
        else
            Assert.True(result);
    }

    [Theory]
    [InlineData("InvalidAddress12345678901234567890123456789012345678901234567890")]
    [InlineData("ValidAddress")]
    public void Validate_CustomerUpdate_Address_InvalidInputs_ReturnsFalse(string address)
    {
        // Arrange
        var customer = new Customer
        {
            Name = "ValidName",
            Address = address
        };

        var viewModel = new CustomerEditViewModel
        {
            Customer = customer
        };

        var modelState = new ModelStateDictionary();

        // Act
        var result = ValidateCustomerUpdate.Validate(viewModel, modelState);

        // Assert
        if (address != null && address.Length > 50)
        {
            Assert.Contains(nameof(viewModel.Customer.Address), modelState.Keys);
            Assert.False(result); // Expecting validation to fail
        }
        else
        {
            Assert.True(result); // Expecting validation to pass
        }
    }


    [Theory]
    [InlineData("InvalidPostCode123")]
    [InlineData("12345")]
    public void Validate_CustomerUpdate_PostCode_InvalidInputs_ReturnsFalse(string postCode)
    {
        // Arrange
        var customer = new Customer
        {
            Name = "ValidName",
            PostCode = postCode
        };

        var viewModel = new CustomerEditViewModel
        {
            Customer = customer
        };

        var modelState = new ModelStateDictionary();

        // Act
        var result = ValidateCustomerUpdate.Validate(viewModel, modelState);

        // Assert
        if (postCode != null && postCode.Length > 4)
        {
            Assert.Contains(nameof(viewModel.Customer.PostCode), modelState.Keys);
            Assert.False(result); // Expecting validation to fail
        }
        else
        {
            Assert.True(result); // Expecting validation to pass
        }
    }

    [Theory]
    [InlineData("InvalidState123")]
    [InlineData("NSW")]
    public void Validate_CustomerUpdate_State_InvalidInputs_ReturnsFalse(string state)
    {
        // Arrange
        var customer = new Customer
        {
            Name = "ValidName",
            State = state
        };

        var viewModel = new CustomerEditViewModel
        {
            Customer = customer
        };

        var modelState = new ModelStateDictionary();

        // Act
        var result = ValidateCustomerUpdate.Validate(viewModel, modelState);

        // Assert
        if (state != null && state.Length > 3)
        {
            Assert.Contains(nameof(viewModel.Customer.State), modelState.Keys);
            Assert.False(result); // Expecting validation to fail
        }
        else
        {
            Assert.True(result); // Expecting validation to pass
        }
    }

    [Theory]
    [InlineData("InvalidMobileNumber123456789")]
    [InlineData("0412 345 678")]
    public void Validate_CustomerUpdate_MobileNumber_InvalidInputs_ReturnsFalse(string mobileNumber)
    {
        // Arrange
        var customer = new Customer
        {
            Name = "ValidName",
            MobileNumber = mobileNumber
        };

        var viewModel = new CustomerEditViewModel
        {
            Customer = customer
        };

        var modelState = new ModelStateDictionary();

        // Act
        var result = ValidateCustomerUpdate.Validate(viewModel, modelState);

        // Assert
        if (mobileNumber != null && mobileNumber.Length > 12)
        {
            Assert.Contains(nameof(viewModel.Customer.MobileNumber), modelState.Keys);
            Assert.False(result); // Expecting validation to fail
        }
        else
        {
            Assert.True(result); // Expecting validation to pass
        }
    }

    [Theory]
    [InlineData("InvalidTFN1234567890123456")]
    [InlineData("123 456 789")]
    public void Validate_CustomerUpdate_TFN_InvalidInputs_ReturnsFalse(string tfn)
    {
        // Arrange
        var customer = new Customer
        {
            Name = "ValidName",
            TFN = tfn
        };

        var viewModel = new CustomerEditViewModel
        {
            Customer = customer
        };

        var modelState = new ModelStateDictionary();

        // Act
        var result = ValidateCustomerUpdate.Validate(viewModel, modelState);

        // Assert
        if (tfn != null && tfn.Length > 11)
        {
            Assert.Contains(nameof(viewModel.Customer.TFN), modelState.Keys);
            Assert.False(result); // Expecting validation to fail
        }
        else
        {
            Assert.True(result); // Expecting validation to pass
        }
    }
}
