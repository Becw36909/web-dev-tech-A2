﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MCBAAdminWebsite.Controllers;
using MCBAAdminWebsite.Tests.Data;
using Microsoft.AspNetCore.Mvc;
using Xunit;
using MCBAAdminWebsite.ViewModels;
using MCBAAdminWebsite.Models;

namespace MCBAAdminWebsite.Tests.Controllers
{
    public class CustomerControllerTests
    {
        private CustomerController Controller;
        private string _AdminName = "admin";

        public CustomerControllerTests()
        {
            Controller = new CustomerController();
            Controller.TempData = new MockTempData();
        }

        [Fact]
        public async void Index_GetCustomerList()
        {
            Controller.ControllerContext.HttpContext = MockHttpContext.Create(_AdminName);

            var result = await Controller.Index();

            // Assert that a view is returned
            var viewResult = Assert.IsType<ViewResult>(result);
            // Assert that a customer model is returned
            var model = Assert.IsType<CustomerIndexViewModel>(viewResult.Model);
            // Assert that Customers is a list
            Assert.IsType<List<Customer>>(model.Customers);

        }


        [Theory]
        [InlineData(null)] // No ID
        [InlineData(9999)] // Customer does not exist
        public async void Edit_Fail_RedirectToIndex(int id)
        {
            Controller.ControllerContext.HttpContext = MockHttpContext.Create(_AdminName);

            var result = await Controller.Edit(2400);

            var redirect = Assert.IsType<RedirectToActionResult>(result);
            Assert.Equal("Index", redirect.ActionName);

        }
    }
}
