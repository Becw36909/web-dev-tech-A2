﻿using Microsoft.AspNetCore.Mvc;
using Xunit;
using MCBAAdminWebsite.Controllers;
using Microsoft.AspNetCore.Http;
using MCBAAdminWebsite.ViewModels;
using MCBAAdminWebsite.Tests.Data;
using MCBAAdminWebsite.Models;
using Microsoft.AspNetCore.Http.HttpResults;

namespace MCBACustomerWebsite.Tests.Controllers
{
    public class LoginControllerTests 
    {

        private LoginController Controller;
        private string _AdminName = "admin";

        public LoginControllerTests()
        {
            Controller = new LoginController();
        }

        [Fact]
        public async void Login_ReturnsLoginView()
        {

            // Act
            var result = Controller.Login();

            // Assert that a view is returned
            var viewResult = Assert.IsType<ViewResult>(result);
            Assert.Equal("Login", viewResult.ViewName);

        }

        [Theory]
        [InlineData("admin","admin")]
        public async void Login_Success_LogsIn_RedirectsToHome(string Username, string Password)
        {
            Controller.ControllerContext.HttpContext = MockHttpContext.Create();

            LoginViewModel LoginViewModel = new LoginViewModel
            {
                Login = new Login
                {
                    Username = Username,
                    Password = Password
                }
            };

            // Act
            var result = await Controller.Login(LoginViewModel);

            var redirect = Assert.IsType<RedirectToActionResult>(result);
            Assert.Equal("Home", redirect.ControllerName);
            Assert.Equal("Index", redirect.ActionName);

        }

        [Theory]
        [InlineData("", "")] // No data
        [InlineData("admin", "")] // No password
        [InlineData("", "admin")] // No Username
        [InlineData("admin", "123abc")] // Correct username Incorrect Password
        [InlineData("abc123", "password")] // Correct password Incorrect Username
        public async void Login_Fails_LogsIn_RedirectsToHome(string Username, string Password)
        {

            LoginViewModel LoginViewModel = new LoginViewModel
            {
                Login = new Login
                {
                    Username = Username,
                    Password = Password
                }
            };

            // Act
            var result = await Controller.Login(LoginViewModel);

            // Assert that a view is returned
            var viewResult = Assert.IsType<ViewResult>(result);
            Assert.Equal("Login", viewResult.ViewName);
            // Assert that errors are returned
            Assert.True(Controller.ModelState.ErrorCount > 0);

        }

        public void Logout_Redirect()
        {
            Controller.ControllerContext.HttpContext = MockHttpContext.Create(_AdminName);
            
            var result = Controller.Logout();

            var redirect = Assert.IsType<RedirectToActionResult>(result);
            Assert.Equal("Login", redirect.ControllerName);
            Assert.Equal("Login", redirect.ActionName);

        }
    }
}
