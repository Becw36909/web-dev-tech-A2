﻿using Microsoft.AspNetCore.Mvc;
using Xunit;
using MCBAAdminWebsite.Controllers;
using Microsoft.AspNetCore.Http;
using MCBAAdminWebsite.ViewModels;
using MCBAAdminWebsite.Tests.Data;

namespace MCBACustomerWebsite.Tests.Controllers
{
    public class HomeControllerTests 
    {

        private HomeController Controller;
        private string _AdminName = "admin";

        public HomeControllerTests()
        {
            Controller = new HomeController();
        }

        [Fact]
        public async void Index_ReturnView_WithCustomer()
        {

            Controller.ControllerContext.HttpContext = MockHttpContext.Create(_AdminName);


            // Act
            var result = Controller.Index();

            // Assert that a view is returned
            var viewResult = Assert.IsType<ViewResult>(result);
            Assert.Equal("Index", viewResult.ViewName);


        }
    }
}
