﻿using MCBAWebAPI.Data;
using MCBAWebAPI.Models;
using Microsoft.SqlServer.Server;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MCBAWebAPI.Tests.Data
{
    public class TestSeeder
    {

        public static void Seed(McbaContext Context)
        {
            if (Context.Set<Customer>().Any())
            {
                return;
            }

            Context.Payees.Add(new Payee
            {
                PayeeId = 1,
                Name = "Optus",
                Address = "123 Fake Street",
                City = "Melbourne",
                PostCode = "3000",
                State = "VIC",
                Phone = "(03) 4156 5660"
            });


            var customers = new Customer[]
            {
                new Customer
                {
                    CustomerID = 1000,
                    Name = "John Doe",
                    Address = "123 Main St",
                    City = "Anytown",
                    PostCode = "1234",
                    State = "VIC",
                    TFN = "123 456 789",
                    MobileNumber = "0412 345 678",
                    Active = true,
                    Accounts = new List<Account>
                    {
                        new Account
                        {
                            AccountNumber = 1000,
                            AccountType = "S",
                            CustomerID = 1000,
                            Balance = 1000,
                            Transactions = new List<Transaction>(),
                            BillPays = new List<BillPay>
                            {
                                new BillPay
                                {
                                    BillPayId = 1,
                                    Period = "O",
                                    AccountNumber = 1000,
                                    PayeeID = 1,
                                    Amount = 5,
                                    ScheduleTimeUtc = DateTime.Now.AddMinutes(5),
                                    State = State.Pending
                                },
                                new BillPay
                                {
                                    BillPayId = 2,
                                    Period = "O",
                                    AccountNumber = 1000,
                                    PayeeID = 1,
                                    Amount = 5,
                                    ScheduleTimeUtc = DateTime.Now.AddMinutes(5),
                                    State = State.Blocked
                                },
                                 new BillPay
                                {
                                    BillPayId = 3,
                                    Period = "O",
                                    AccountNumber = 1000,
                                    PayeeID = 1,
                                    Amount = 5,
                                    ScheduleTimeUtc = DateTime.Now.AddMinutes(5),
                                    State = State.Completed
                                },
                            },
                        },
                    }

                },
                // Add more customers as needed

            };

            Context.Set<Customer>().AddRange(customers);
            Context.SaveChanges();
        }   
    }
}
