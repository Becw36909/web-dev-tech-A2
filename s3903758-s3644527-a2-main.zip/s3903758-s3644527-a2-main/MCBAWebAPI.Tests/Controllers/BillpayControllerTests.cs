﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xunit;
using MCBAWebAPI.Tests.Fixtures;
using Microsoft.AspNetCore.Mvc;
using MCBAWebAPI.Controllers;
using MCBAWebAPI.Data;
using MCBAWebAPI.Models;
using MCBAWebAPI.Models.DataManager;
using MCBAWebAPI.Tests.Data;

namespace MCBAWebAPI.Tests.Controllers
{

    public class BillpayControllerTests : IClassFixture<SqliteTestFixture>
    {
        private McbaContext _Context;
        private BillPayController Controller;

        public BillpayControllerTests(SqliteTestFixture fixture)
        {
            _Context = fixture.CreateContext();
            BillPayManager BillPayManager = new BillPayManager(_Context);
            Controller = new BillPayController(BillPayManager);
        }

        [Fact]
        public void Index_GetBillpayList()
        {
            // Arrange

            // Act
            var result = Controller.Index();

            // Assert that a billpay list is returned
            Assert.IsAssignableFrom<List<BillPay>>(result);

        }


        [Theory]
        [InlineData(1)] // Change from Pending to Blocked
        [InlineData(2)] // Change from Blocked to Pending
        public void ToggleAccess_Success(int BillPayId)
        {
            // Arrange

            // Act
            var Toggled = Controller.ToggleAccess(BillPayId);

            // Assert that true is returned
            Assert.Equal(Toggled, true);
        }

        [Theory]
        [InlineData(null)] // No customer ID
        [InlineData(9999)] // No Customer in Database
        [InlineData(3)] // Completed billpay
        public void ToggleAccess_Fail(int BillPayId)
        {
            // Act
            var Toggled = Controller.ToggleAccess(BillPayId);

            Assert.Equal(Toggled, false);

        }


    }
}
