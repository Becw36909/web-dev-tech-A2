﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xunit;
using MCBAWebAPI.Tests.Fixtures;
using Microsoft.AspNetCore.Mvc;
using MCBAWebAPI.Controllers;
using MCBAWebAPI.Data;
using MCBAWebAPI.Models;
using MCBAWebAPI.Models.DataManager;
using MCBAWebAPI.Tests.Data;

namespace MCBAWebAPI.Tests.Controllers
{

    [CollectionDefinition("CustomerControllerTestCollection", DisableParallelization = true)]
    public class CustomerControllerTestCollection { }


    [Collection("CustomerControllerTestCollection")]
    public class CustomerControllerTests : IClassFixture<SqliteTestFixture>
    {
        private McbaContext _Context;
        private CustomerController Controller;

        public CustomerControllerTests(SqliteTestFixture fixture)
        {
            _Context = fixture.CreateContext();
            CustomerManager CustomerManager = new CustomerManager(_Context);
            Controller = new CustomerController(CustomerManager);
        }

        [Fact]
        public void Index_GetCustomerList()
        {
            // Arrange

            // Act
            var result = Controller.Index();

            // Assert
            Assert.IsAssignableFrom<List<Customer>>(result);

        }

        [Theory]
        [InlineData(1000)]
        public void Show_Success_GetCustomer(int CustomerID)
        {
            // Act
            var result = Controller.Show(CustomerID);

            // Assert that customer is returned
            Assert.IsAssignableFrom<Customer>(result);

        }

        [Theory]
        [InlineData(null)] // No customer ID
        [InlineData(9999)] // No Customer in Database
        public void Show_Fail_GetCustomer(int CustomerID)
        {

            // Act
            var result = Controller.Show(CustomerID);

            // Assert
            Assert.Null(result);

        }

        [Theory]
        [InlineData(1000, "Doe John", "Abbey Road", "Sydney", "2000", "NSW", "123 123 123", "0400 000 000")] // All valid values
        
        [InlineData(1000, "John Doe", null, null, null, null, null, null)] // Required values only
        [InlineData(1000, "A", "A", "A", "1234", "NT", "111 111 111", "0400 000 000")] //Test Minimum character inputs
        [InlineData(1000, TestData.ch50, TestData.ch50, TestData.ch40, "1234", "NSW", "111 111 111", "0400 000 000")] //Test Maximum character inputs

        public void Update_Success_UpdateCustomer(int CustomerID, string Name, string Address, String City, String PostCode, String State, String TFN, String MobileNumber)
        {

            Customer Customer = new Customer
            {
                CustomerID = CustomerID,
                Name = Name,
                Address = Address,
                City = City,
                PostCode = PostCode,
                State = State,
                TFN = TFN,
                MobileNumber = MobileNumber
            };

            var result = Controller.Update(Customer);

            // Assert that the response is true
            Assert.True(result);


        }

        [Theory]
        [InlineData(null, "Spiderman", null, null, null, null, null, null)] // No Customer ID
        [InlineData(9999, "Toby Mcguire", null, null, null, null, null, null)] // No Customer ID
        [InlineData(1, null, null, null, null, null, null, null)] // No Username
        [InlineData(1, TestData.ch51, TestData.ch41, TestData.ch51, TestData.ch51, TestData.ch51, TestData.ch51, TestData.ch51)] // max+1 character input
        [InlineData(1, "John Doe", null, null, null, "ABCD", null, null)] // Postcode Is not letters
        [InlineData(1, "John Doe", null, null, null, "123", null, null)] // Postcode that is not exactly 4 digits
        [InlineData(1, "John Doe", null, null, null, null, "1111 111 11", null)] // Incorrect TFN format
        [InlineData(1, "John Doe", null, null, null, null, null, "03 020 303 30")] // Incorrect mobile format
        public void Update_Fail_UpdateCustomer(int CustomerID, string Name, string Address, String City, String PostCode, String State, String TFN, String MobileNumber)
        {

            Customer Customer = new Customer
            {
                CustomerID = CustomerID,
                Name = Name,
                Address = Address,
                City = City,
                PostCode = PostCode,
                State = State,
                TFN = TFN,
                MobileNumber = MobileNumber
            };

            var result = Controller.Update(Customer);
            // Assert that the response is false
            Assert.False(result);
        }

        [Theory]
        [InlineData(1000)]
        public void ToggleAccess_Success(int customerID)
        {
            // Arrange
            // Get existing customer data
            Customer Customer = Controller.Show(customerID);
            bool ActiveStatus = Customer.Active;

            // Act
            var Toggled = Controller.ToggleAccess(customerID);

            // Assert that true is returned
            Assert.Equal(Toggled, true);
            // Assert that customer model has updated in database.
            Customer Updated_Customer = Controller.Show(customerID);
            Assert.NotEqual(ActiveStatus, Updated_Customer.Active);
        }

        [Theory]
        [InlineData(null)] // No customer ID
        [InlineData(9999)] // No Customer in Database
        public void ToggleAccess_Fail(int customerID)
        {
            // Act
            var Toggled = Controller.ToggleAccess(customerID);

            Assert.Equal(Toggled, false);


        }


    }
}
