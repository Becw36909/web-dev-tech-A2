﻿using MCBAWebAPI.Models;
using System;
using System.Collections.Generic;
using Xunit;

namespace MCBAWebAPI.Tests
{
    public class AccountTests
    {
        [Theory]
        [InlineData("S", "Savings")]
        [InlineData("C", "Checking")]
        public void TestGetAccountType(string accountType, string expectedAccountType)
        {
            // Arrange
            var account = new Account
            {
                AccountType = accountType
            };

            // Act
            string actualAccountType = account.GetAccountType();

            // Assert
            Assert.Equal(expectedAccountType, actualAccountType);
        }

        [Theory]
        [InlineData(1001, 500, 200, 700)] // Initial balance: 500, Transaction amount: 200
        [InlineData(2002, 1500, -300, 1200)] // Initial balance: 1500, Transaction amount: -300
        public void TestCalculateBalance(int accountNumber, decimal initialBalance, decimal transactionAmount, decimal expectedBalance)
        {
            // Arrange
            var account = new Account
            {
                AccountNumber = accountNumber,
                Balance = initialBalance
            };
            var transaction = new Transaction
            {
                Amount = transactionAmount
            };

            // Act
            decimal newBalance = account.CalculateBalance(transaction);

            // Assert
            Assert.Equal(expectedBalance, newBalance);
        }
    }
}
