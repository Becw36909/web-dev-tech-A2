﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using MCBAWebAPI.Models;
using Xunit;

namespace MCBAWebAPI.Tests.Models
{
    public class CustomerTests
    {
        public static IEnumerable<object[]> MobileNumberData => new List<object[]>
        {
            new object[] { "0401 234 567", true },
            new object[] { "0412 345 678", true },
            new object[] { "0423 456 789", true },
            new object[] { "0434 567 890", true },
            new object[] { "Invalid", false }
        };

        [Theory]
        [InlineData(123, "John Doe", "123 Main St", "City", "1234", "VIC", "123 456 789 01", "0401 234 567", true)]
        [InlineData(456, "Jane Smith", "456 Elm St", "City", "5678", "NSW", "234 567 890 12", "0412 345 678", true)]
        [InlineData(789, "Invalid Customer", null, null, "9999", null, "345 678 901 23", "Invalid", false)]
        public void ToggleAccess_TogglesCustomerActiveState(int customerId, string name, string address, string city,
            string postCode, string state, string tfn, string mobileNumber, bool initialActiveState)
        {
            // Arrange
            var customer = new Customer
            {
                CustomerID = customerId,
                Name = name,
                Address = address,
                City = city,
                PostCode = postCode,
                State = state,
                TFN = tfn,
                MobileNumber = mobileNumber,
                Active = initialActiveState
            };

            // Act
            customer.ToggleAccess();

            // Assert
            Assert.NotEqual(initialActiveState, customer.Active);
        }

        [Theory]
        [MemberData(nameof(MobileNumberData))]
        public void MobileNumber_ValidatesCorrectFormat(string mobileNumber, bool expectedResult)
        {
            // Arrange
            var customer = new Customer { MobileNumber = mobileNumber };

            // Act
            var validationResults = new List<ValidationResult>();
            bool isValid = Validator.TryValidateProperty(customer.MobileNumber, new ValidationContext(customer)
            {
                MemberName = nameof(customer.MobileNumber)
            }, validationResults);

            // Assert
            Assert.Equal(expectedResult, isValid);
        }

        [Theory]
        [InlineData("John Doe", true)]
        [InlineData("Address Value", true)]
        [InlineData("City Value", true)]
        [InlineData("1234", true)]
        public void Property_ValidatesRequiredStringLength(string propertyValue, bool expectedResult)
        {
            // Arrange
            var propertyName = "Name"; // Replace with the actual property name being tested
            var customer = new Customer();

            // Set the property value using reflection
            var property = typeof(Customer).GetProperty(propertyName);
            property.SetValue(customer, propertyValue);

            // Act
            var validationResults = new List<ValidationResult>();
            bool isValid = Validator.TryValidateProperty(property.GetValue(customer), new ValidationContext(customer)
            {
                MemberName = propertyName
            }, validationResults);

            // Assert
            Assert.Equal(expectedResult, isValid);
        }
    }
}
