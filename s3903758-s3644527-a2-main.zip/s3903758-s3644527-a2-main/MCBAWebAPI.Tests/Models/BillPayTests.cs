﻿using System;
using System.Collections.Generic;
using System.Runtime.Serialization;
using MCBAWebAPI.Models;
using Xunit;

namespace MCBAWebAPI.Tests.Models
{
    public class BillPayTests
    {

        [Theory]
        [InlineData("O", "One-Off")]
        [InlineData("M", "Monthly")]
        public void GetBillPayPeriod_ReturnsExpectedPeriod(string inputPeriod, string expectedPeriod)
        {
            // Arrange
            BillPay Billpay = new BillPay { Period = inputPeriod };

            // Act
            string period = Billpay.GetBillPayPeriod();

            // Assert
            Assert.Equal(expectedPeriod, period);
        }
    }

}
