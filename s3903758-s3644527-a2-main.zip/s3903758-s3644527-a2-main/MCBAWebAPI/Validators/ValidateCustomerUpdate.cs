﻿using MCBAWebAPI.Models;
using Microsoft.AspNetCore.Mvc.ModelBinding;
using System.Text.RegularExpressions;
using MCBAWebAPI.Models.DataManager;

namespace MCBAWebAPI.Validators
{
    public class ValidateCustomerUpdate
    {

        public static bool Validate(Customer customer)
        {
            bool validationCheck = true; 

            // Validate Name Input
            if(customer.Name == null || customer.Name.Length < 0 || customer.Name.Length > 50)
            {
                validationCheck = false;
            }
            // Validate Address Input
            if(customer.Address != null && customer.Address.Length > 50)
            {
                validationCheck = false;
            }
            // Validate Postcode Input
            if(customer.PostCode != null && customer.PostCode.Length > 4)
            {
                validationCheck = false;
            }
            // Validate State Input
            if(customer.State != null && customer.State.Length > 3)
            {
                validationCheck = false;
            }

            // State has to be either blank or one of the choices in the statemap.
            if (customer.State != null && !Customer.StateMap.ContainsKey(customer.State)){
                validationCheck = false;
            }

            if(customer.TFN != null && 
                !Regex.IsMatch(customer.TFN, @"^\d{3} \d{3} \d{3}$"))
            {
                validationCheck = false;
            }

            if (customer.MobileNumber != null && 
                !Regex.IsMatch(customer.MobileNumber, @"^04\d{2} \d{3} \d{3}$"))
            {
                validationCheck = false;
            }

            return validationCheck;
        }

    }
}
