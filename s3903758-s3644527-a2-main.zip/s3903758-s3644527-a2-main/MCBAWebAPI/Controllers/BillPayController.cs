﻿using Microsoft.AspNetCore.Mvc;
using MCBAWebAPI.Models;
using MCBAWebAPI.Models.DataManager;

namespace MCBAWebAPI.Controllers;

[ApiController]
[Route("api/[controller]")]
public class BillPayController
{
    private readonly BillPayManager _repo;

    public BillPayController(BillPayManager repo)
    {
        _repo = repo;
    }

    // GET: api/billpay
    [HttpGet]
    public IEnumerable<BillPay> Index()
    {
        return _repo.GetAllBillPays();
    }

    // Get api/billpay/toggleBlock/{billpayID}
    [HttpGet("toggleBlock/{billpayID}")]
    public bool ToggleAccess(int billpayID)
    {

            BillPay Billpay = _repo.GetBillPay(billpayID);

            if(Billpay == null || Billpay.State == State.Completed || Billpay.State == State.Failed)
        {
            return false;
        }

            Billpay.ToggleBlock();

            bool result = _repo.UpdateBillPay(billpayID, Billpay);

        return result;

    }

}

