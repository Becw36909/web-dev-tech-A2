﻿using Microsoft.AspNetCore.Mvc;
using MCBAWebAPI.Models;
using MCBAWebAPI.Models.DataManager;
using MCBAWebAPI.Validators;

namespace MCBAWebAPI.Controllers;

[ApiController]
[Route("api/[controller]")]
public class CustomerController : ControllerBase
{
    private readonly CustomerManager _repo;

    public CustomerController(CustomerManager repo)
    {
        _repo = repo;
    }

    // GET: api/customer
    [HttpGet]
    public IEnumerable<Customer>Index()
    {
        return _repo.GetAllCustomers();
    }

    // GET api/customer/1
    [HttpGet("{customerID}")]
    public Customer Show(int CustomerID)
    {
        return _repo.GetCustomer(CustomerID);
    }

    // Post api/customer/1
    [HttpPost("{customerID}")]
    public bool Update([FromBody] Customer customer)
    {
        // Validate posted customer object.
        if(customer == null || !ValidateCustomerUpdate.Validate(customer)) { return false; }

        // check that customer exists, return error if doesn't
        bool result = _repo.UpdateCustomer(customer.CustomerID, customer);

        return result;
    }

    // Get api/customer/toggleAccess/{customerID}
    [HttpGet("toggleAccess/{customerID}")]
    public bool ToggleAccess(int customerID)
    {
        // Return if ID is null
        if(customerID == null) { return false; }

        // Get customer
        Customer Customer = _repo.GetCustomer(customerID);
        // Return if customer cant be retrieved
        if(Customer == null) { return false; }  

        // Toggle Customer Access
        Customer.ToggleAccess();
        // Update customer
        bool updated = _repo.CustomerAccess(customerID, Customer);
        // Return result
        return updated;

    }

}
