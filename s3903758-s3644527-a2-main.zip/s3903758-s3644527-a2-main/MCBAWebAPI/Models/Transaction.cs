﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace MCBAWebAPI.Models;

public enum TransactionType
{
    Deposit = 1,
    Withdraw = 2,
    Transfer = 3,
    ServiceCharge = 4,
    BillPay = 5,
}

public class Transaction
{
    public int TransactionID { get; set; }

    public TransactionType TransactionType { get; set; }

    [ForeignKey("Account")]
    [Required]
    public int AccountNumber { get; set; }
    public virtual Account Account { get; set; }

    [ForeignKey("DestinationAccount")]
    public int? DestinationAccountNumber { get; set; }
    public virtual Account DestinationAccount { get; set; }

    [Column(TypeName = "money"), DataType(DataType.Currency),]
    [Required]
    public decimal Amount { get; set; }

    [StringLength(30, MinimumLength = 0, ErrorMessage = "Comment cannot be longer than 30 characters")]
    public string Comment { get; set; }

    [DataType(DataType.Date)]
    [DisplayFormat(DataFormatString = "{0:DD/MM/YYYY}", ApplyFormatInEditMode = true)]
    public DateTime TransactionTimeUtc { get; set; }


    public void SetAccountNumber(int accountNumber)
    {
        AccountNumber = accountNumber;
    }

}
