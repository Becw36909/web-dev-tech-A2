﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace MCBAWebAPI.Models;


public class Account
{
    [Key, DatabaseGenerated(DatabaseGeneratedOption.None)]
    [Display(Name = "Account Number")]
    [Required]
    public int AccountNumber { get; set; }

    [Display(Name = "Type")]
    public string AccountType { get; set; }

    public int CustomerID { get; set; }
    public virtual Customer Customer { get; set; }

    [Column(TypeName = "money"), DataType(DataType.Currency)]
    public decimal Balance { get; set; }

    // Set ambiguous navigation property with InverseProperty annotation or Fluent-API in the McbaContext.cs file.
    [InverseProperty("Account")]
    public virtual List<Transaction> Transactions { get; set; }

    // Set ambiguous navigation property with InverseProperty annotation or Fluent-API in the McbaContext.cs file.
    [InverseProperty("Account")]
    public virtual List<BillPay> BillPays { get; set; }

    private decimal _checkingAccountMinBalance = 300;
    private decimal _surcharge = 0;


    private static readonly Dictionary<string, string> AccountTypeMap = new Dictionary<string, string>()
    {
        { "S", "Savings" },
        { "C", "Checking" }
    };

    public string GetAccountType()
    {
        return (AccountTypeMap.ContainsKey(AccountType)) ? AccountTypeMap[this.AccountType] : AccountType;
    }

    public decimal CalculateBalance(Transaction transaction)
    {
        Balance += transaction.Amount;

        return Balance;
    }

}
