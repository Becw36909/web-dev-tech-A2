﻿namespace MCBAWebAPI.Models.Repository;

public interface IDataRepository<TEntity, TKey> where TEntity : class
{
    //IEnumerable<TEntity> GetAllCustomers();
    //TEntity GetCustomer(TKey id);

    //TKey Add(TEntity item);
    //TKey UpdateCustomer(TKey id, TEntity item);
    //TKey Delete(TKey id);

    //IEnumerable<TEntity> GetAllBillPays();
    //TKey UpdateBillPay(TKey id, TEntity item);
}
