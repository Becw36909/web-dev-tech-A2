﻿using MCBAWebAPI.Data;
using MCBAWebAPI.Models.Repository;
using Microsoft.EntityFrameworkCore;

namespace MCBAWebAPI.Models.DataManager;

public class BillPayManager : IDataRepository<BillPay, int>
{
    private readonly McbaContext _context;

    public BillPayManager(McbaContext context)
    {
        _context = context;
    }

    public IEnumerable<BillPay> GetAllBillPays()
    {
        return _context.BillPays.ToList();
    }

    public BillPay GetBillPay(int BillPayID)
    {
        return _context.BillPays.Find(BillPayID);
    }

    public bool UpdateBillPay(int id, BillPay billPay)
    {
        try
        {
            _context.Update(billPay);
            _context.SaveChanges();
            return true;
        }
        catch (DbUpdateException ex)
        {
            return false;
        }
    }
}
