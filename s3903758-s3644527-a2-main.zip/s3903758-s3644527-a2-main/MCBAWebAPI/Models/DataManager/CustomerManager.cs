﻿using MCBAWebAPI.Data;
using MCBAWebAPI.Models.Repository;
using Microsoft.EntityFrameworkCore;
using System.Linq.Expressions;

namespace MCBAWebAPI.Models.DataManager;

public class CustomerManager : IDataRepository<Customer, int>
{
    private readonly McbaContext _context;

    public CustomerManager(McbaContext context)
    {
        _context = context;
    }

    public IEnumerable<Customer> GetAllCustomers()
    {
        return _context.Customers.ToList();
    }

    public Customer GetCustomer(int CustomerID)
    {
        return _context.Customers.Find(CustomerID);
    }

    public bool UpdateCustomer(int id, Customer customer)
    {
        try {
            _context.Update(customer);
            _context.SaveChanges();

            return true;
        }
       catch (DbUpdateException ex)
        {
            return false;
        }

    }

    public bool CustomerAccess(int id, Customer customer)
    {
        try
        {
            _context.Update(customer);
            _context.SaveChanges();
            return true;
        }
        catch (DbUpdateException ex)
        {
            return false;
        }
    }

}
