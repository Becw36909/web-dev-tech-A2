using Microsoft.EntityFrameworkCore;
using MCBAWebAPI.Data;
using MCBAWebAPI.Models.DataManager;


var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddDbContext<McbaContext>(options =>
    options.UseSqlServer(builder.Configuration.GetConnectionString(nameof(McbaContext))));

builder.Services.AddScoped<CustomerManager>();
builder.Services.AddScoped<BillPayManager>();


builder.Services.AddControllers();

// Ignore JSON reference cycles during serialisation.
builder.Services.AddControllers().AddJsonOptions(options =>
    options.JsonSerializerOptions.ReferenceHandler = System.Text.Json.Serialization.ReferenceHandler.IgnoreCycles);

var app = builder.Build();


// Configure the HTTP request pipeline.

// next bit is optional, can just run on http if wanted
app.UseHttpsRedirection();

// the assignment does not require login/logout on API so this is
// not necessary
//app.UseAuthorization();

app.MapControllers();

app.Run();
