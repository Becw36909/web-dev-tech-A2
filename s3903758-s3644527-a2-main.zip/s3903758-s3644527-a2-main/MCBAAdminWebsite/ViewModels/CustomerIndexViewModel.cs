﻿using MCBAAdminWebsite.Models;

namespace MCBAAdminWebsite.ViewModels
{
    public class CustomerIndexViewModel
    {
        public IEnumerable<Customer> Customers { get; set; } = new List<Customer>();
    }
}
