﻿using MCBAAdminWebsite.Models;

namespace MCBAAdminWebsite.ViewModels
{
    public class CustomerEditViewModel
    {
        public Customer Customer { get; set; }

        public Dictionary<string, string> StateOptions { get; set;  } = Customer.StateMap;
    }
}
