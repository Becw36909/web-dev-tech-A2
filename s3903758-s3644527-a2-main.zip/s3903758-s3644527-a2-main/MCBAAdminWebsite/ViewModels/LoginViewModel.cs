﻿using MCBAAdminWebsite.Models;

namespace MCBAAdminWebsite.ViewModels
{
    public class LoginViewModel
    {

      public Login Login { get; set; }

    }
}