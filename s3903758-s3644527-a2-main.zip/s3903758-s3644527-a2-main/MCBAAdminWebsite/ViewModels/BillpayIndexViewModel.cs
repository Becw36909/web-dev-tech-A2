﻿using MCBAAdminWebsite.Models;

namespace MCBAAdminWebsite.ViewModels
{
    public class BillpayIndexViewModel
    {

        public IEnumerable<Billpay> Billpays { get; set; } = new List<Billpay>();
        public State BlockedState = Billpay.GetBlockedState();

    }
}
