﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using Microsoft.EntityFrameworkCore.Update.Internal;
using MCBAAdminWebsite.ViewModels;

namespace MCBAAdminWebsite.Models
{
    public class Customer
    {
        [Required]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int CustomerID { get; set; }

        [Required, StringLength(50)]
        public string Name { get; set; }

        [StringLength(50)]
        public string? Address { get; set; }

        [StringLength(40)]
        public string? City { get; set; }

        [RegularExpression(@"^\d{4}$", ErrorMessage = "PostCode must be exactly 4 digits.")]
        [StringLength(4, ErrorMessage = "PostCode must be exactly 4 digits.")]
        public string? PostCode { get; set; }

        [StringLength(3)]
        public string? State { get; set; }

        [RegularExpression(@"^\d{3} \d{3} \d{3}$", ErrorMessage = "TFN must be of the format: XXX XXX XXX")]
        [StringLength(11)]
        public string? TFN { get; set; }

        [RegularExpression(@"^04\d{2} \d{3} \d{3}$", ErrorMessage = "Mobile number must be of the format: 04XX XXX XXX")]
        [StringLength(12)]
        public string? MobileNumber { get; set; }


        public bool Active { get; set; }


        public static readonly Dictionary<string, string> StateMap = new Dictionary<string, string>()
    {
        { "ACT", "Australian Capital Territory" },
        { "NSW", "New South Wales" },
        { "NT", "Northern Territory" },
        { "QLD", "Queensland" },
        { "SA", "South Australia" },
        { "TAS", "Tasmania" },
        { "WA", "Western Australia" },
        { "VIC", "Victoria" },

    };

    }
}
