﻿using Microsoft.EntityFrameworkCore.Metadata.Internal;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System.Xml.Linq;

namespace MCBAAdminWebsite.Models
{
    public enum State
    {
        Pending = 1,
        Failed = 2,
        Completed = 3,
        Blocked = 4,
    }

    public class Billpay
    {
        public int BillPayId { get; set; }

        [Display(Name = "Type")]
        [Required]
        public string Period { get; set; }

        [Required]
        public State State { get; set; }

        [ForeignKey("Account")]
        [Required]
        public int AccountNumber { get; set; }


        [ForeignKey("Payee")]
        [Required]
        public int PayeeID { get; set; }


        // Must be a positive value
        [Column(TypeName = "money"), DataType(DataType.Currency),]
        [Required]
        public decimal Amount { get; set; }

        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:DD/MM/YYYY}", ApplyFormatInEditMode = true)]
        [Required]
        public DateTime ScheduleTimeUtc { get; set; }

        public static State GetBlockedState()
        {
            return State.Blocked;
        }

        private static readonly Dictionary<string, string> BillPayPeriodMap = new Dictionary<string, string>()
    {
        { "O", "One-Off" },
        { "M", "Monthly" }
    };

        public string GetBillPayPeriod()
        {
            return (BillPayPeriodMap.ContainsKey(Period)) ? BillPayPeriodMap[this.Period] : Period;
        }
    }
}
