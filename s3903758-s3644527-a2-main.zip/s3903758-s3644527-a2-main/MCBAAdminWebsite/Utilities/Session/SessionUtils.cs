﻿using Microsoft.AspNetCore.Http;

namespace MCBAAdminWebsite.Utilities.Session
{
    public static class SessionUtils
    {
        private const string SessionKey_AdminName = "Name";

        public static string GetAdminName(this ISession session) =>
            session.GetString(SessionKey_AdminName);

        public static void SetAdminName(this ISession session, string name) =>
            session.SetString(SessionKey_AdminName, name);

        public static bool IsLoggedIn(this ISession session) {

            string Name = GetAdminName(session);

            return (Name == null || Name.Length == 0) ? false : true;


         }

        public static bool IsAnonymous(this ISession session) => !session.IsLoggedIn();

    }
}
