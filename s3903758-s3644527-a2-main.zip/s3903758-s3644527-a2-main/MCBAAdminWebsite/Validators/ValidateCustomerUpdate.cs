﻿using MCBAAdminWebsite.Models;
using MCBAAdminWebsite.ViewModels;
using Microsoft.AspNetCore.Mvc.ModelBinding;

namespace MCBAAdminWebsite.Validators
{
    public class ValidateCustomerUpdate
    {

        public static bool Validate(CustomerEditViewModel viewModel, ModelStateDictionary ModelState)
        {
            Customer Input = viewModel.Customer;
            bool validationCheck = true;


            // Validate Name Input
            if(Input.Name.Length <= 0 || Input.Name.Length > 50)
            {
                ModelState.AddModelError(nameof(viewModel.Customer.Name), 
                    "A profile name must be between 0 and 50 characters long.");
                validationCheck = false;
            }
            // Validate Address Input
            if(Input.Address != null && Input.Address.Length > 50)
            {
                ModelState.AddModelError(nameof(viewModel.Customer.Address), 
                    "The address cannot be greater than 50 characters long.");
                validationCheck = false;
            }
            // Validate Postcode Input
            if(Input.PostCode != null && Input.PostCode.Length > 4)
            {
                ModelState.AddModelError(nameof(viewModel.Customer.PostCode), 
                    "The Postcode cannot be greater than 4 characters long.");
                validationCheck = false;
            }
            // Validate State Input
            if(Input.State != null && Input.State.Length > 3)
            {
                ModelState.AddModelError(nameof(viewModel.Customer.State), 
                    "The state cannot be greater than 3 characters long.");
                validationCheck = false;
            }
            // Validate Mobile Phone Number
            if (Input.MobileNumber != null && Input.MobileNumber.Length > 12)
            {
                ModelState.AddModelError(nameof(viewModel.Customer.MobileNumber), 
                    "The mobile number cannot be greater than 12 characters long.");
                validationCheck = false;
            }
            // Validate Tax FileNumber
            if (Input.TFN != null && Input.TFN.Length >11)
            {
                ModelState.AddModelError(nameof(viewModel.Customer.TFN), 
                    "The tax file number cannot be greater than 11 characters long.");
                validationCheck = false;
            }

            // State has to be either blank or one of the choices in the statemap.


            return validationCheck;
        }

    }
}
