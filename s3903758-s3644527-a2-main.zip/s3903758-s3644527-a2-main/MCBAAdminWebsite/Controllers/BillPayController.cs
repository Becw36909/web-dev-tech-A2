﻿using Microsoft.AspNetCore.Mvc;
using MCBAAdminWebsite.Models;
using MCBAAdminWebsite.ViewModels;
using MCBAAdminWebsite.Filters;
using Microsoft.EntityFrameworkCore;
using MCBAAdminWebsite.Validators;
using Newtonsoft.Json;
using System.Text;

namespace MCBAAdminWebsite.Controllers
{
    [AuthorizeAdmin]
    public class BillPayController : Controller
    {

        public async Task<IActionResult> Index()
        {

            try
            {
                HttpResponseMessage response = await HttpClientWrapper.InitializeClient().GetAsync("api/billpay");

                response.EnsureSuccessStatusCode();

                // Storing the response details recieved from web api.
                var result = response.Content.ReadAsStringAsync().Result;

                // Deserializing the response recieved from web api and storing into a list.
                var billpays = JsonConvert.DeserializeObject<List<Billpay>>(result);


                return View(new BillpayIndexViewModel { Billpays = billpays });

            }
            catch (HttpRequestException ex)
            {

                return View(new CustomerIndexViewModel());
            }

        }

        [HttpGet]
        public async Task<IActionResult> Toggle(int id)
        {
            if (id == null)
            {
                TempData["Error"] = "Failed changing Customer active status.";
                return RedirectToAction("Index");
            }


            var response = HttpClientWrapper.InitializeClient().GetAsync($"api/billpay/toggleBlock/{id}").Result;

            if (response.IsSuccessStatusCode)
            {
                // Success Flash Message
                TempData["Success"] = "Payment status has been updated.";
                // Return to User Profile
                return RedirectToAction("index");
            }


            TempData["Error"] = "Request failed. Status code: " + response.StatusCode;
            return RedirectToAction("Index");

        }
    }
}
