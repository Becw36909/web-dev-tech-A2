﻿using MCBAAdminWebsite.Utilities.Session;
using Microsoft.AspNetCore.Mvc;
using MCBAAdminWebsite.ViewModels;
using Microsoft.EntityFrameworkCore;
using MCBAAdminWebsite.Models;

namespace MCBAAdminWebsite.Controllers
{
    [Route("/Login")]
    public class LoginController : Controller
    {

        public IActionResult Login() => View("Login", new LoginViewModel());

        [HttpPost]
        public async Task<IActionResult> Login(LoginViewModel LoginViewModel)
        {
            // Return error if does not match
            if (LoginViewModel.Login.Username != "admin" || LoginViewModel.Login.Password != "admin")
            {
                ModelState.AddModelError("LoginFailed", "Incorrect credentials, Please try again.");

                return View("Login", LoginViewModel);
            }

            // Login Admin.

            HttpContext.Session.SetAdminName(LoginViewModel.Login.Username);

            return RedirectToAction("Index", "Home");
        }

        [Route("Logout")]
        public IActionResult Logout()
        {
            // Logout customer.
            HttpContext.Session.Clear();

            return Redirect("/Login");
        }
    }
}
