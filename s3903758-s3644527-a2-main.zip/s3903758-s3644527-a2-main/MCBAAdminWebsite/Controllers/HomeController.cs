﻿using MCBAAdminWebsite.Filters;
using MCBAAdminWebsite.Models;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;

namespace MCBAAdminWebsite.Controllers
{
    [AuthorizeAdmin]
    public class HomeController : Controller
    {

        public IActionResult Index()
        {
            return View("Index");
        }

    }
}