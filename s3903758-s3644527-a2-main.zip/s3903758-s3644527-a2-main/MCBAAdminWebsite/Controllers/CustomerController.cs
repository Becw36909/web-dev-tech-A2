﻿using Microsoft.AspNetCore.Mvc;
using MCBAAdminWebsite.Models;
using MCBAAdminWebsite.ViewModels;
using MCBAAdminWebsite.Filters;
using Microsoft.EntityFrameworkCore;
using MCBAAdminWebsite.Validators;
using Newtonsoft.Json;
using System.Text;
using System.Net.Http;
using System.ComponentModel;

namespace MCBAAdminWebsite.Controllers
{
    [AuthorizeAdmin]
    public class CustomerController : Controller
    {

        public async Task<IActionResult> Index()
        {

            try
            {
                HttpResponseMessage response = await HttpClientWrapper.InitializeClient().GetAsync("api/customer");

                response.EnsureSuccessStatusCode();

                // Storing the response details recieved from web api.
                var result = response.Content.ReadAsStringAsync().Result;

                // Deserializing the response recieved from web api and storing into a list.
                var customers = JsonConvert.DeserializeObject<List<Customer>>(result);


                return View("Index", new CustomerIndexViewModel { Customers = customers });

            }
            catch (HttpRequestException ex)
            {
                
                return View(new CustomerIndexViewModel());
            }
  
        }

        [HttpGet]
        public async Task<IActionResult> Edit(int? id)
        {
            if(id == null)
            {
                return RedirectToAction("Index");
            }

            try
            {
                HttpResponseMessage response = await HttpClientWrapper.InitializeClient().GetAsync($"api/customer/{id}");

                response.EnsureSuccessStatusCode();

                
                // Storing the response details recieved from web api.

                var result = response.Content.ReadAsStringAsync().Result;

                if(result.Length == 0)
                {
                    // Success Flash Message
                    TempData["error"] = $"Could not retrieve User Details for Customer ID: {id}";
                    // Return to homepage
                    return RedirectToAction("Index");
                }

                // Deserializing the response recieved from web api 
                Customer customer = JsonConvert.DeserializeObject<Customer>(result);


                return View("edit", new CustomerEditViewModel { Customer = customer });

            }
            catch (HttpRequestException ex)
            {
                // Success Flash Message
                TempData["error"] = $"Could not retrieve User Details for Customer ID: {id}";
                // Return to homepage
                return RedirectToAction("Index");
            }
        }

        [HttpPost]
        public async Task<IActionResult> Update(CustomerEditViewModel ViewModel)
        {

                var content = new StringContent(JsonConvert.SerializeObject(ViewModel.Customer), Encoding.UTF8, "application/json");
                var response = HttpClientWrapper.InitializeClient().PostAsync($"api/customer/{ViewModel.Customer.CustomerID}", content).Result;

                if (response.IsSuccessStatusCode)
                {
                    // Success Flash Message
                    TempData["Success"] = "Customer details have been successfully updated.";
                    // Return to User Profile
                    return RedirectToAction("index");
                }


            TempData["Error"] = "Customer details have not been updated.";
            ViewModel.StateOptions = Customer.StateMap;
            return View("edit", ViewModel);

        }

        [HttpGet]
        public async Task<IActionResult> Toggle(int? id)
        {
            if(id == null)
            {
                TempData["Error"] = "Failed changing Customer active status.";
                return RedirectToAction("Index");
            }


            var response = HttpClientWrapper.InitializeClient().GetAsync($"api/customer/toggleAccess/{id}").Result;

            if (response.IsSuccessStatusCode)
            {
                // Success Flash Message
                TempData["Success"] = "Customer status has been successfully updated.";
                // Return to User Profile
                return RedirectToAction("index");
            }


            TempData["Error"] = "Request failed. Status code: " + response.StatusCode;
            return RedirectToAction("Index");

        }

    }
}
