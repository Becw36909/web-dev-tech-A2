using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace MCBAAdminWebsite.Views.Billpay
{
    public class IndexModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
