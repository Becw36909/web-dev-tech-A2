using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace MCBACustomerWebsite.Views.Shared
{
    public class _LoginLayoutModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
