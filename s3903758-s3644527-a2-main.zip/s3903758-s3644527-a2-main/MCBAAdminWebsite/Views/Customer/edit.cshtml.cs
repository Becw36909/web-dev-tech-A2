using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace MCBAAdminWebsite.Views.Customer
{
    public class editModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
