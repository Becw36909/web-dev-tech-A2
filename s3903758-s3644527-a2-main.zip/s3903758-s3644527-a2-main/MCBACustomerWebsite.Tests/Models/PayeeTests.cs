﻿using System;
using System.Collections.Generic;
using MCBACustomerWebsite.Models;
using Xunit;

namespace MCBACustomerWebsite.Tests.Models
{
    public class PayeeTests
    {
        [Theory]
        [InlineData("ACT", "Australian Capital Territory")]
        [InlineData("NSW", "New South Wales")]
        [InlineData("NT", "Northern Territory")]
        [InlineData("QLD", "Queensland")]
        [InlineData("SA", "South Australia")]
        [InlineData("TAS", "Tasmania")]
        [InlineData("WA", "Western Australia")]
        [InlineData("VIC", "Victoria")]
        [InlineData("InvalidState", "")]
        public void GetStateName_ReturnsCorrectStateName(string state, string expectedStateName)
        {
            // Arrange
            var payee = new Payee { State = state };

            // Act
            string stateName = payee.GetStateName();

            // Assert
            Assert.Equal(expectedStateName, stateName);
        }

        [Fact]
        public void GetStateName_ReturnsEmptyForNullState()
        {
            // Arrange
            var payee = new Payee();

            // Act
            string stateName = payee.GetStateName();

            // Assert
            Assert.Equal("", stateName);
        }
    }
}
