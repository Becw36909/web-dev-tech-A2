﻿using Xunit;
using MCBACustomerWebsite.Models;
using MCBACustomerWebsite.Tests.Fixtures;
using MCBACustomerWebsite.Data;
using Microsoft.EntityFrameworkCore;

namespace MCBACustomerWebsite.Tests
{
    public class AccountTests : IClassFixture<SqliteTestFixture>
    {
        private readonly SqliteTestFixture _fixture;
        private readonly McbaContext _context;

        public AccountTests(SqliteTestFixture fixture)
        {
            _fixture = fixture;
            _context = _fixture.CreateContext();
        }

        [Theory]
        [InlineData("Savings", 500, TransactionType.Deposit, 100, 600)]
        [InlineData("Checking", 1000, TransactionType.Deposit, 200, 1200)]
        public async Task TestCalculateInitialBalance(string accountType, decimal initialBalance,
            TransactionType transactionType, decimal transactionAmount, decimal expectedBalance)
        {
            // Arrange
                var account = new Account
                {
                    AccountType = accountType,
                    Balance = initialBalance,
                    Transactions = _context.Transactions.ToList()
                };
                var transaction = new Transaction
                {
                    TransactionType = transactionType,
                    Amount = transactionAmount,
                };

                // Act
                decimal newBalance = account.CalculateInitialBalance(transaction);

                // Assert
                Assert.Equal(expectedBalance, newBalance);
            }


        [Theory]
        [InlineData("S", 500, 500)] // Valid data for Savings
        [InlineData("C", 1000, 700)] // Valid data for Checking
        public async Task TestCalculateAvailableBalance_ValidData(string accountType, decimal balance, decimal expectedAvailableBalance)
        {
            // Arrange
                var account = new Account
                {
                    AccountType = accountType,
                    Balance = balance,
                };

                // Act
                decimal availableBalance = account.CalculateAvailableBalance();

                // Assert
                Assert.Equal(expectedAvailableBalance, availableBalance);
        }

        [Theory]
        [InlineData("S", 500, -100)] // Invalid expected balance for Savings
        [InlineData("C", 1000, -500)] // Invalid expected balance for Checking
        public async Task TestInvalidExpectedBalance(string accountType, decimal balance, decimal expectedAvailableBalance)
        {
            // Arrange
                var account = new Account
                {
                    AccountType = accountType,
                    Balance = balance,
                };

                // Act
                decimal actualAvailableBalance = account.CalculateAvailableBalance();

                // Assert
                Assert.NotEqual(expectedAvailableBalance, actualAvailableBalance);
          
        }

        [Theory]
        [InlineData(1000, 3)] // AccountNumber 1000 has 3 eligible transactions
        [InlineData(2000, 2)] // AccountNumber 2000 has 1 eligible transaction
        public async Task TestSurchargeCheck_TransactionCounts(int accountNumber, int expectedTransactionCount)
        {
            // Arrange
                var account = _context.Accounts
                    .Include(a => a.Transactions)
                    .FirstOrDefault(a => a.AccountNumber == accountNumber);

                // Act
                int transactionTypeCheck = account.SurchargeCheck(_context, accountNumber);

                // Assert
                Assert.Equal(expectedTransactionCount, transactionTypeCheck);          
        }

        [Theory]
        [InlineData(1000, 1000, 50, "Test deposit")]
        public async Task TestStoreDeposit(int accountNumber, decimal initialBalance, decimal depositAmount, string depositComment)
        {
            // Arrange
                var account = _context.Accounts
                    .Include(a => a.Transactions)
                    .FirstOrDefault(a => a.AccountNumber == accountNumber);

                var initialTransactionCount = account.Transactions.Count;

                // Act
                await account.StoreDeposit(_context, depositAmount, depositComment);
                await _context.SaveChangesAsync();

                // Assert
                var updatedAccount = _context.Accounts
                    .Include(a => a.Transactions)
                    .FirstOrDefault(a => a.AccountNumber == accountNumber);

                Assert.NotNull(updatedAccount);
                Assert.Equal(initialBalance + depositAmount, updatedAccount.Balance);
                Assert.Equal(initialTransactionCount + 1, updatedAccount.Transactions.Count);

                var lastTransaction = updatedAccount.Transactions.LastOrDefault();
                Assert.NotNull(lastTransaction);
                Assert.Equal(TransactionType.Deposit, lastTransaction.TransactionType);
                Assert.Equal(depositAmount, lastTransaction.Amount);
                Assert.Equal(depositComment, lastTransaction.Comment);
        }

        [Theory]
        [InlineData(1001, 900, 20, "Test withdrawal")] // Initial balance: 900, Withdrawal amount: 20
        [InlineData(2002, 1900, 50, "Another withdrawal")] // Initial balance: 1900, Withdrawal amount: 50
        public async Task TestStoreWithdrawal(int accountNumber, decimal initialBalance, decimal withdrawalAmount, string withdrawalComment)
        {
            // Arrange
            var account = _context.Accounts
                .Include(a => a.Transactions)
                .FirstOrDefault(a => a.AccountNumber == accountNumber);

            // Act
            await account.StoreWithdrawal(_context, withdrawalAmount, withdrawalComment);

            // Calculate the expected balance after the withdrawal
            decimal expectedBalance = initialBalance - withdrawalAmount;

            // Assert
            Assert.Equal(expectedBalance, account.Balance);
            Assert.Single(account.Transactions, transaction =>
                transaction.TransactionType == TransactionType.Withdraw &&
                transaction.Amount == withdrawalAmount &&
                transaction.Comment == withdrawalComment);
        }


        [Theory]
        [InlineData(1002, 1000, 100, "Transfer to Account 1001")] // Initial balance: 1000, Transfer amount: 100
        [InlineData(2003, 1500, 200, "Transfer to Account 2002")] // Initial balance: 1500, Transfer amount: 200
        public async Task TestStoreTransfer(int destinationAccount, decimal initialBalance, decimal transferAmount, string transferComment)
        {
            // Arrange
            var account = _context.Accounts
                .Include(a => a.Transactions)
                .FirstOrDefault(a => a.AccountNumber == destinationAccount);

            // Act
            await account.StoreOutgoingTransfer(_context, transferAmount, transferComment, destinationAccount);

            // Calculate the expected balance after the transfer
            decimal expectedBalance = initialBalance - transferAmount;

            // Assert
            var updatedAccount = _context.Accounts.FirstOrDefault(a => a.AccountNumber == destinationAccount);
            Assert.Equal(expectedBalance, updatedAccount.Balance);

            var newTransaction = _context.Transactions
                .OrderByDescending(t => t.TransactionTimeUtc)
                .FirstOrDefault();

            Assert.NotNull(newTransaction);
            Assert.Equal(TransactionType.Transfer, newTransaction.TransactionType);
            Assert.Equal(transferAmount, newTransaction.Amount);
            Assert.Equal(transferComment, newTransaction.Comment);
        }

        [Theory]
        [InlineData(1003, 5000, 100, "Transfer deposit")] // Initial balance: 5000, Deposit amount: 100
        [InlineData(2004, 500, 200, "Another transfer deposit")] // Initial balance: 500, Deposit amount: 200
        public async Task TestStoreTransferDeposit(int accountNumber, decimal initialBalance, decimal depositAmount, string depositComment)
        {
            // Arrange
            var account = _context.Accounts
                .Include(a => a.Transactions)
                .FirstOrDefault(a => a.AccountNumber == accountNumber);

            // Act
            await account.StoreTransferDeposit(_context, depositAmount, depositComment);

            // Calculate the expected balance after the deposit
            decimal expectedBalance = initialBalance + depositAmount;

            // Assert
            var updatedAccount = _context.Accounts.FirstOrDefault(a => a.AccountNumber == accountNumber);
            Assert.Equal(expectedBalance, updatedAccount.Balance);

            var newTransaction = _context.Transactions
                .OrderByDescending(t => t.TransactionTimeUtc) // Add an OrderBy operation here
                .FirstOrDefault();

            Assert.NotNull(newTransaction);
            Assert.Equal(TransactionType.Transfer, newTransaction.TransactionType);
            Assert.Equal(depositAmount, newTransaction.Amount);
            Assert.Equal(depositComment, newTransaction.Comment);
        }

        [Theory]
        [InlineData(1004, 780, 0.10)] // Initial balance: 900, Transfer Surcharge amount: 0.10
        [InlineData(2005, 650, 0.05)] // Initial balance: 1900, Withdrawal Surcharge amount: 0.05 
        public async Task TestStoreSurcharge(int accountNumber, decimal initialBalance, decimal surchargeAmount)
        {
            // Arrange
            var account = _context.Accounts
                .Include(a => a.Transactions)
                .FirstOrDefault(a => a.AccountNumber == accountNumber);

            // Act
            await account.StoreSurcharge(_context, surchargeAmount);

            // Calculate the expected balance after the surcharge
            decimal expectedBalance = initialBalance - surchargeAmount;

            // Assert
            var updatedAccount = _context.Accounts.FirstOrDefault(a => a.AccountNumber == accountNumber);
            Assert.Equal(expectedBalance, updatedAccount.Balance);

            var newTransaction = _context.Transactions
                .OrderByDescending(t => t.TransactionTimeUtc) // Add an OrderBy operation here
                .FirstOrDefault();

            Assert.NotNull(newTransaction);
            Assert.Equal(TransactionType.ServiceCharge, newTransaction.TransactionType);
            Assert.Equal(surchargeAmount, newTransaction.Amount);
        }

        [Theory]
        [InlineData("O", State.Pending, 1005, 100, "2023-08-09")] // One-Off BillPay, Pending state, Account 1005, Amount 100, Schedule Date: 2023-08-09
        [InlineData("M", State.Pending, 2006, 200, "2023-08-09")] // Monthly BillPay, Pending state, Account 2006, Amount 200, Schedule Date: 2023-08-09
        public async Task TestStoreBillPayWithdrawal(
            string period, State state, int accountNumber, decimal billPayAmount, string scheduleDate)
        {
            // Arrange
            var account = _context.Accounts
                .Include(a => a.Transactions)
                .FirstOrDefault(a => a.AccountNumber == accountNumber);

            decimal initialBalance = account.Balance;

            var billPay = new BillPay
            {
                Period = period,
                State = state,
                AccountNumber = accountNumber,
                Amount = billPayAmount,
                ScheduleTimeUtc = DateTime.Parse(scheduleDate).ToUniversalTime()
            };

            // Act
            await account.StoreBillPayWithdrawal(_context, billPay);

            // Calculate the expected balance after the bill payment withdrawal
            decimal expectedBalance = initialBalance - billPay.Amount;

            // Assert
            var updatedAccount = _context.Accounts.FirstOrDefault(a => a.AccountNumber == accountNumber);
            Assert.Equal(expectedBalance, updatedAccount.Balance);

            var newTransaction = _context.Transactions
                .Where(t => t.Account.AccountNumber == accountNumber)
                .OrderByDescending(t => t.TransactionTimeUtc) // Sort transactions by time in descending order
                .FirstOrDefault();

            Assert.NotNull(newTransaction);
            Assert.Equal(TransactionType.BillPay, newTransaction.TransactionType);
            Assert.Equal(billPayAmount, newTransaction.Amount);
        }


    }
}
