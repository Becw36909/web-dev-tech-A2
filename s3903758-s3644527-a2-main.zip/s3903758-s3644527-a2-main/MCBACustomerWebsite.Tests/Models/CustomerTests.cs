﻿using MCBACustomerWebsite.Models;
using Xunit;

namespace MCBACustomerWebsite.Tests.Models;

// No tests yet for Profile Picture methods

public class CustomerTests
{
    [Theory]
    [InlineData("Updated Customer", "987 654 321", "0432 123 456", "Updated Address", "Updated City", "VIC", "5678", true)]
    [InlineData(null, "987 654 321", "0432 123 456", "Updated Address", "Updated City", "VIC", "5678", true)] // Invalid Name (required)
    [InlineData("Updated Customer", "987654321", "0432 123 456", "Updated Address", "Updated City", "VIC", "5678", true)] // Invalid TFN (format)
    [InlineData("Updated Customer", "987 654 321", "0432123456", "Updated Address", "Updated City", "VIC", "5678", true)] // Invalid MobileNumber (format)
    [InlineData("Updated Customer", "987 654 321", "0432 123 456", "Updated Address", "Updated City", "VIC", "123", true)] // Invalid PostCode (format)
    public void Update_ShouldUpdateCustomerProperties(string newName, string newTFN, string newMobileNumber, string newAddress,
                                                     string newCity, string newState, string newPostCode, bool isValid)
    {
        // Arrange
        var customer = new Customer
        {
            CustomerID = 1,
            Name = "Test Customer",
            TFN = "123 456 789",
            MobileNumber = "0412 345 678",
            Address = "Test Address",
            City = "Test City",
            State = "NSW",
            PostCode = "1234"
        };

        var propertiesToUpdate = new Dictionary<string, string>
        {
            { "Name", newName },
            { "TFN", newTFN },
            { "MobileNumber", newMobileNumber },
            { "Address", newAddress },
            { "City", newCity },
            { "State", newState },
            { "PostCode", newPostCode }
        };

        // Act - Directly set the customer properties
        foreach (var property in propertiesToUpdate)
        {
            // Find the property and set its value
            var customerProperty = typeof(Customer).GetProperty(property.Key);
            customerProperty.SetValue(customer, property.Value);
        }

        // Assert
        if (isValid)
        {
            Assert.Equal(newName, customer.Name);
            Assert.Equal(newTFN, customer.TFN);
            Assert.Equal(newMobileNumber, customer.MobileNumber);
            Assert.Equal(newAddress, customer.Address);
            Assert.Equal(newCity, customer.City);
            Assert.Equal(newState, customer.State);
            Assert.Equal(newPostCode, customer.PostCode);
        }
        else
        {
            // If the data is invalid, the customer properties should remain unchanged
            Assert.Equal("Test Customer", customer.Name);
            Assert.Equal("123 456 789", customer.TFN);
            Assert.Equal("0412 345 678", customer.MobileNumber);
            Assert.Equal("Test Address", customer.Address);
            Assert.Equal("Test City", customer.City);
            Assert.Equal("NSW", customer.State);
            Assert.Equal("1234", customer.PostCode);
        }
    }

    [Theory]
    [InlineData("NSW", "New South Wales")]
    [InlineData("VIC", "Victoria")]
    [InlineData("QLD", "Queensland")]
    [InlineData("WA", "Western Australia")]
    [InlineData("SA", "South Australia")]
    [InlineData("TAS", "Tasmania")]
    [InlineData("NT", "Northern Territory")]
    [InlineData("ACT", "Australian Capital Territory")]
    [InlineData("XYZ", "")]
    public void GetStateName_ShouldReturnStateName(string state, string expectedStateName)
    {
        // Arrange
        var customer = new Customer { State = state };

        // Act
        var stateName = customer.GetStateName();

        // Assert
        Assert.Equal(expectedStateName, stateName);
    }


}
