﻿using MCBACustomerWebsite.Models;
using Xunit;

namespace MCBACustomerWebsite.Tests.Models;

// Only testing (simulated) password updating, as this test class
// does not actually call login.UpdatePassword() as no dbcontext to pass in

public class LoginTests
{
    private string GetHashedPassword(string password)
    {
        // Replace this with required password hashing method
        return "hashed:" + password;
    }

    [Theory]
    [InlineData("validPassword")]
    public void UpdatePassword_ShouldUpdatePasswordHash_ReturnsTrue(string newPassword)
    {
        // Arrange
        var login = new Login
        {
            LoginID = "validLoginID",
            PasswordHash = "hashed:originalPassword"
        };

        // Act (Simulate the update)
        login.PasswordHash = GetHashedPassword(newPassword);

        // Assert
        Assert.Equal("hashed:" + newPassword, login.PasswordHash);
    }

    [Theory]
    [InlineData("")]
    [InlineData(null)]
    [InlineData("short")]
    [InlineData("toolongpassword")]
    public void UpdatePassword_ShouldNotUpdateInvalidPassword_ReturnsFalse(string newPassword)
    {
        // Arrange
        var login = new Login
        {
            LoginID = "validLoginID",
            PasswordHash = "hashed:originalPassword"
        };

        // Act (Simulate the update attempt)
        bool updateResult = !string.IsNullOrEmpty(newPassword) && newPassword.Length == 94; // Simulate the constraint check

        // Assert
        Assert.False(updateResult);
        Assert.Equal("hashed:originalPassword", login.PasswordHash);
    }
}

