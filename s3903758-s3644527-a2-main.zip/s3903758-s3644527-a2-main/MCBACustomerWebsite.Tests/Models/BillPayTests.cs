﻿using MCBACustomerWebsite.Models;
using Xunit;

namespace MCBACustomerWebsite.Tests.Models
{
    public class BillPayTests
    {
        [Theory]
        [InlineData("O", "One-Off")]
        [InlineData("M", "Monthly")]
        public void GetBillPayPeriod_ReturnsExpectedPeriod(string inputPeriod, string expectedPeriod)
        {
            // Arrange
            BillPay Billpay = new BillPay
            {
                BillPayId = 1,
                Period = inputPeriod,
                AccountNumber = 1,
                PayeeID = 1,
                Amount = 1,
                ScheduleTimeUtc = DateTime.Now,
                State = State.Pending
            };

            // Act
            string period = Billpay.GetBillPayPeriod();

            // Assert
            Assert.Equal(expectedPeriod, period);
        }
    }
}
