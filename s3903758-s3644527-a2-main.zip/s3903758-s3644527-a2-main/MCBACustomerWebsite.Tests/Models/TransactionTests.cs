﻿using System;
using MCBACustomerWebsite.Models;
using Xunit;

namespace MCBACustomerWebsite.Tests.Models
{
    public class TransactionTests
    {
        [Theory]
        [InlineData(TransactionType.Deposit, 100.0, "")]
        [InlineData(TransactionType.Withdraw, 50.0, "Withdrawal")]
        [InlineData(TransactionType.Transfer, 75.0, "Transfer")]
        [InlineData(TransactionType.ServiceCharge, 10.0, "Service Charge")]
        [InlineData(TransactionType.BillPay, 200.0, "Bill Payment")]
        public void SetAccountNumber_SetsTransactionTypeAndComment(TransactionType transactionType, decimal amount, string expectedComment)
        {
            // Arrange
            var transaction = new Transaction();
            var accountNumber = 123;

            // Act
            transaction.SetAccountNumber(accountNumber);
            transaction.TransactionType = transactionType;
            transaction.Amount = amount;

            // Set Comment based on TransactionType
            switch (transactionType)
            {
                case TransactionType.Deposit:
                    transaction.Comment = "";
                    break;
                case TransactionType.Withdraw:
                    transaction.Comment = "Withdrawal";
                    break;
                case TransactionType.Transfer:
                    transaction.Comment = "Transfer";
                    break;
                case TransactionType.ServiceCharge:
                    transaction.Comment = "Service Charge";
                    break;
                case TransactionType.BillPay:
                    transaction.Comment = "Bill Payment";
                    break;
                default:
                    throw new ArgumentOutOfRangeException(nameof(transactionType), transactionType, null);
            }

            // Assert
            Assert.Equal(accountNumber, transaction.AccountNumber);
            Assert.Equal(transactionType, transaction.TransactionType);
            Assert.Equal(expectedComment, transaction.Comment);
        }
    }
}
