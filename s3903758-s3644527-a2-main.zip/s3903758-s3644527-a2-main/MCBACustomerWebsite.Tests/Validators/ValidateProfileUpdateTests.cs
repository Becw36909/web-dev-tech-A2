﻿using MCBACustomerWebsite.Models;
using MCBACustomerWebsite.Validators;
using MCBACustomerWebsite.ViewModels;
using Microsoft.AspNetCore.Mvc.ModelBinding;
using Xunit;

namespace MCBACustomerWebsite.Tests.Validators;

public class ValidateProfileUpdateTests
{
    [Theory]
    [InlineData("John Doe", null, null, null, true)]
    [InlineData("John Doe", "Sample Address", null, null, true)]
    [InlineData("John Doe", "Sample Address", "1234", null, true)]
    [InlineData("John Doe", "Sample Address", "1234", "VIC", true)]
    [InlineData(null, null, null, null, false)]
    [InlineData("John DoeJohn DoeJohn DoeJohn DoeJohn DoeJohn DoeJohn DoeJohn DoeJohn DoeJohn DoeJohn DoeJohn DoeJohn DoeJohn Doe", null, null, null, false)]
    [InlineData("John Doe", "Sample Address Sample Address Sample Address Sample Address Sample Address Sample Address", null, null, false)]
    [InlineData("John Doe", null, "12345", null, false)]
    [InlineData("John Doe", "Sample Address", "12345", null, false)]
    [InlineData("John Doe", null, null, "InvalidState", false)]
    [InlineData("John Doe", null, null, "VICVIC", false)]
    public void Validate_ShouldReturnExpectedResult(
         string name, string address, string postCode, string state, bool expectedValidationResult)
    {
        // Arrange
        var viewModel = new ProfileEditViewModel
        {
            Customer = new Customer
            {
                Name = name,
                Address = address,
                PostCode = postCode,
                State = state
            }
        };
        var modelState = new ModelStateDictionary();

        // Act
        bool validationResult = ValidateProfileUpdate.Validate(viewModel, modelState);

        // Assert
        Assert.Equal(expectedValidationResult, validationResult);

        // If expectedValidationResult is False and state is not null or not in the StateMap, then there should be an error message for State
        if (!expectedValidationResult && (state != null && !Customer.StateMap.ContainsKey(state)))
        {
            Assert.True(modelState.ContainsKey(nameof(viewModel.Customer.State)));

            // Assert that the error message contains the expected keywords
            var stateError = modelState[nameof(viewModel.Customer.State)].Errors[0].ErrorMessage;
            Assert.True(stateError.ToLower().Contains("state") || stateError.ToLower().Contains("australia"));
        }
        else
        {
            // If expectedValidationResult is True or state is null or in the StateMap, then there should not be an error message for State
            Assert.False(modelState.ContainsKey(nameof(viewModel.Customer.State)));
        }
    }
}
