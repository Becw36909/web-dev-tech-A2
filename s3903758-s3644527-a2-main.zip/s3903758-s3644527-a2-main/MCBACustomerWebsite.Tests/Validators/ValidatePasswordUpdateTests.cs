﻿using MCBACustomerWebsite.Models;
using MCBACustomerWebsite.ViewModels;
using MCBACustomerWebsite.Validators;
using Microsoft.AspNetCore.Mvc.ModelBinding;
using Xunit;
using SimpleHashing.Net;

namespace MCBACustomerWebsite.Tests.Validators
{
    public class ValidatePasswordUpdateTests
    {
        public static IEnumerable<object[]> ValidationTestData()
        {
            // Test cases: Password, NewPassword, ConfirmNewPassword, ExpectedIsValid
            yield return new object[] { "oldPassword", "newPassword", "newPassword", true };
            yield return new object[] { DBNull.Value, "newPassword", "newPassword", false };
            yield return new object[] { "oldPassword", "newPassword", "differentPassword", false };
            yield return new object[] { "oldPassword", "newPassword", "newPassword", true };
        }

        [Theory]
        [MemberData(nameof(ValidationTestData))]
        public void ValidatePasswordUpdate_ReturnsExpectedResult(object oldPassword, string newPassword, string confirmNewPassword, bool expectedIsValid)
        {
            // Arrange
            var viewModel = new ProfileIndexViewModel
            {
                Password = oldPassword as string,
                NewPassword = newPassword,
                ConfirmNewPassword = confirmNewPassword
            };

            var login = new Login
            {
                PasswordHash = new SimpleHash().Compute("oldPassword")
            };

            var modelState = new ModelStateDictionary();

            // Act
            bool isValid = ValidatePasswordUpdate.Validate(viewModel, modelState, login);

            // Assert
            Assert.Equal(expectedIsValid, isValid);
            Assert.Equal(expectedIsValid ? 0 : 1, modelState.ErrorCount);
        }
    }
}
