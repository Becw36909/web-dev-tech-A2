﻿using MCBACustomerWebsite.Data;
using Microsoft.EntityFrameworkCore;
using Microsoft.Data.Sqlite;
using MCBACustomerWebsite.Tests.Data;
using MCBACustomerWebsite.Models;

namespace MCBACustomerWebsite.Tests.Fixtures
{
    public class SqliteTestFixture : IDisposable
    {
        private readonly SqliteConnection _connection;
        private readonly DbContextOptions<McbaContext> _options;

        public SqliteTestFixture()
        {
            _connection = new SqliteConnection("DataSource=:memory:");
            _connection.Open();

            _options = new DbContextOptionsBuilder<McbaContext>()
                .UseSqlite(_connection)
                .Options;

            using (var context = new McbaContext(_options))
            {
                context.Database.EnsureCreated();

                // Seed if there is no data.
                if(!context.Set<Customer>().Any())
                {
                    TestSeeder.Seed(context);
                }
                
            }
        }

        public McbaContext CreateContext() => new McbaContext(_options);

        public void Dispose()
        {
            _connection.Close();
        }
    }
}