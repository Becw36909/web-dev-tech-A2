﻿using MCBACustomerWebsite.Utilities.Session;
using Microsoft.AspNetCore.Http;

namespace MCBACustomerWebsite.Tests.Data
{
    public class MockHttpContext
    {

        public static HttpContext Create(int CustomerID)
        {
            HttpContext HttpContext = new DefaultHttpContext();
            HttpContext.Session = new MockSession();
            HttpContext.Session.SetCustomerID(CustomerID);


            return HttpContext;
        }

    }
}
