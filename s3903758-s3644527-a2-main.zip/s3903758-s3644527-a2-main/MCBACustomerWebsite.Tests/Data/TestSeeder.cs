﻿using MCBACustomerWebsite.Data;
using MCBACustomerWebsite.Models;
using Microsoft.SqlServer.Server;

namespace MCBACustomerWebsite.Tests.Data
{
    public class TestSeeder
    {
        const string format = "dd/MM/yyyy hh:mm:ss tt";

        public static void Seed(McbaContext Context)
        {

            if (Context.Set<Customer>().Any())
            {
                return; // Database already seeded
            }

            Context.Payees.Add(new Payee
            {
                PayeeId = 1,
                Name = "Optus",
                Address = "123 Fake Street",
                City = "Melbourne",
                PostCode = "3000",
                State = "VIC",
                Phone = "(03) 4156 5660"
            });

            var customers = new Customer[]
            {
            new Customer
            {
                CustomerID = 1,
                Name = "John Doe",
                Address = "123 Main St",
                City = "Anytown",
                PostCode = "1234",
                State = "VIC",
                TFN = "123 456 789",
                MobileNumber = "0412 345 678",
                Active = true,
                Login = new Login
                {
                    LoginID = "12345678",
                    CustomerID = 1,
                    PasswordHash = "Rfc2898DeriveBytes$50000$MrW2CQoJvjPMlynGLkGFrg==$x8iV0TiDbEXndl0Fg8V3Rw91j5f5nztWK1zu7eQa0EE="
                },
                Accounts = new List<Account>
                {
                    new Account
                    {
                      AccountNumber = 1000,
                        AccountType = "S",
                        CustomerID = 1,
                        Balance = 1000,
                        Transactions = new List<Transaction>
                        {
                            new Transaction
                            {
                                TransactionType = TransactionType.Deposit,
                                AccountNumber = 1000,
                                Amount = 600,
                                Comment = "First deposit",
                                TransactionTimeUtc = DateTime.ParseExact("02/01/2023 08:30:00 PM", format, null)
                            },
                                                        
                            new Transaction
                            {
                                TransactionType = TransactionType.Withdraw,
                                AccountNumber = 1000,
                                Amount = 20,
                                Comment = "First withdrawal",
                                TransactionTimeUtc = DateTime.ParseExact("03/01/2023 08:30:00 PM", format, null)
                            },
                                                        
                            new Transaction
                            {
                                TransactionType = TransactionType.Transfer,
                                AccountNumber = 1000,
                                Amount = 30,
                                Comment = "First transfer",
                                DestinationAccountNumber = 1001,
                                TransactionTimeUtc = DateTime.ParseExact("04/01/2023 08:30:00 PM", format, null)
                            },
                                                        
                            new Transaction
                            {
                                TransactionType = TransactionType.Transfer,
                                AccountNumber = 1000,
                                Amount = 30,
                                Comment = "Second transfer",
                                DestinationAccountNumber = 2000,
                                TransactionTimeUtc = DateTime.ParseExact("05/01/2023 08:30:00 PM", format, null)
                            }
                        },
                         BillPays = new List<BillPay>
                        {
                            new BillPay
                            {
                                BillPayId = 1,
                                Period = "O",
                                AccountNumber = 1000,
                                PayeeID = 1,
                                Amount = 5,
                                ScheduleTimeUtc = DateTime.Now.AddMinutes(5),
                                State = State.Pending
                              },
                            new BillPay
                            {
                                BillPayId = 10,
                                Period = "O",
                                AccountNumber = 1000,
                                PayeeID = 1,
                                Amount = 5,
                                ScheduleTimeUtc = DateTime.Now.AddMinutes(-5),
                                State = State.Failed
                              },
                            new BillPay
                            {
                                BillPayId = 4,
                                Period = "O",
                                AccountNumber = 1000,
                                PayeeID = 1,
                                Amount = 900,
                                ScheduleTimeUtc = DateTime.Now.AddMinutes(5),
                                State = State.Blocked
                              },
                            new BillPay
                            {
                                BillPayId = 5,
                                Period = "O",
                                AccountNumber = 1000,
                                PayeeID = 1,
                                Amount = 900,
                                ScheduleTimeUtc = DateTime.Now.AddMinutes(5),
                                State = State.Completed
                              },

                        },
                    },
                    new Account
                    {
                        AccountNumber = 1001,
                        AccountType = "C",
                        CustomerID = 1,
                        Balance = 900,
                        Transactions = new List<Transaction>()
                        {
                             new Transaction
                            {
                                TransactionType = TransactionType.Transfer,
                                AccountNumber = 1001,
                                Amount = 1,
                                Comment = "test transfer",
                                DestinationAccountNumber = 2000,
                                TransactionTimeUtc = DateTime.ParseExact("05/01/2023 08:30:00 PM", format, null)
                            }
                        },
                        BillPays = new List<BillPay>
                        {
                            new BillPay
                            {
                                BillPayId = 3,
                                Period = "O",
                                AccountNumber = 1001,
                                PayeeID = 1,
                                Amount = 19000,
                                ScheduleTimeUtc = DateTime.Now,
                                State = State.Failed
                              },
                             new BillPay
                            {
                                BillPayId = 6,
                                Period = "O",
                                AccountNumber = 1001,
                                PayeeID = 1,
                                Amount = 601,
                                ScheduleTimeUtc = DateTime.Now,
                                State = State.Failed
                              },
                        }
                    },
                    new Account
                    {
                        AccountNumber = 1002,
                        AccountType = "C",
                        CustomerID = 1,
                        Balance = 1000,
                    },
                                        
                    new Account
                    {
                        AccountNumber = 1003,
                        AccountType = "C",
                        CustomerID = 1,
                        Balance = 5000,
                    },
                                        
                    new Account
                    {
                        AccountNumber = 1004,
                        AccountType = "C",
                        CustomerID = 1,
                        Balance = 780,
                    },
                                        
                    new Account
                    {
                        AccountNumber = 1005,
                        AccountType = "C",
                        CustomerID = 1,
                        Balance = 550,
                    },
                }

            },
            new Customer
            {
                CustomerID = 2,
                Name = "Jane Smith",
                Address = "456 Elm St",
                City = "Smallville",
                PostCode = "5678",
                State = "NSW",
                TFN = "987 654 321",
                MobileNumber = "0421 987 654",
                Active = true,
                Login = new Login
                {
                    LoginID = "17963428",
                    CustomerID = 2,
                    PasswordHash = "Rfc2898DeriveBytes$50000$jDBijGZNWLh+0MOXnp68Yw==$4bQ9SJGtRQJolToCjFTPsVzRtH8QQUpEsioJ6Y3ewN4="
                },
                Accounts = new List<Account>
                {
                    new Account
                    {
                        AccountNumber = 2000,
                        AccountType = "S",
                        CustomerID = 2,
                        Balance = 500,
                        Transactions = new List<Transaction>
                        {
                            new Transaction
                            {
                                TransactionType = TransactionType.Transfer,
                                AccountNumber = 2000,
                                Amount = 50,
                                Comment = "First transfer",
                                DestinationAccountNumber = 1000,
                                TransactionTimeUtc = DateTime.ParseExact("06/01/2023 08:30:00 PM", format, null)
                            },
                                                       
                            new Transaction
                            {
                                TransactionType = TransactionType.Withdraw,
                                AccountNumber = 2000,
                                Amount = 50,
                                Comment = "First withdrawal",
                                TransactionTimeUtc = DateTime.ParseExact("07/01/2023 08:30:00 PM", format, null)
                            }
                        }
                    },
                    new Account
                    {
                        AccountNumber = 2002,
                        AccountType = "C",
                        CustomerID = 2,
                        Balance = 1900,
                    },
                                        
                    new Account
                    {
                        AccountNumber = 2003,
                        AccountType = "C",
                        CustomerID = 2,
                        Balance = 1500,
                    },
                                        
                    new Account
                    {
                        AccountNumber = 2004,
                        AccountType = "C",
                        CustomerID = 2,
                        Balance = 500,
                    },
                                        
                    new Account
                    {
                        AccountNumber = 2005,
                        AccountType = "C",
                        CustomerID = 2,
                        Balance = 650,
                    },
                                        
                    new Account
                    {
                        AccountNumber = 2006,
                        AccountType = "C",
                        CustomerID = 2,
                        Balance = 980,
                    },
                }
            },
            new Customer
            {
                CustomerID = 20,
                Name = "Deposit Tests",
                Active = true,
                Login = new Login
                {
                    LoginID = "20000000",
                    CustomerID = 20,
                    PasswordHash = "Rfc2898DeriveBytes$50000$MrW2CQoJvjPMlynGLkGFrg==$x8iV0TiDbEXndl0Fg8V3Rw91j5f5nztWK1zu7eQa0EE="
                },
                Accounts = new List<Account>
                {
                    new Account
                    {
                      AccountNumber = 1200,
                        AccountType = "S",
                        CustomerID = 20,
                        Balance = 1000,
                        Transactions = new List<Transaction>(),
                         BillPays = new List<BillPay>(),
                    },
                    new Account
                    {
                        AccountNumber = 1201,
                        AccountType = "C",
                        CustomerID = 20,
                        Balance = 1000,
                        Transactions = new List<Transaction>(),
                        BillPays = new List<BillPay>(),
                    },
                }

            },
            new Customer
            {
                CustomerID = 21,
                Name = "Withdraw Tests",
                Active = true,
                Login = new Login
                {
                    LoginID = "21000000",
                    CustomerID = 21,
                    PasswordHash = "Rfc2898DeriveBytes$50000$MrW2CQoJvjPMlynGLkGFrg==$x8iV0TiDbEXndl0Fg8V3Rw91j5f5nztWK1zu7eQa0EE="
                },
                Accounts = new List<Account>
                {
                    new Account
                    {
                      AccountNumber = 1210,
                        AccountType = "S",
                        CustomerID = 21,
                        Balance = 1000,
                        Transactions = new List<Transaction>(),
                         BillPays = new List<BillPay>(),
                    },
                    new Account
                    {
                        AccountNumber = 1211,
                        AccountType = "C",
                        CustomerID = 21,
                        Balance = 1000,
                        Transactions = new List<Transaction>(),
                        BillPays = new List<BillPay>(),
                    },
                }

            },
                // Add more customers as needed
            };



            Context.Set<Customer>().AddRange(customers);
            Context.SaveChanges();
        }
    }
}
