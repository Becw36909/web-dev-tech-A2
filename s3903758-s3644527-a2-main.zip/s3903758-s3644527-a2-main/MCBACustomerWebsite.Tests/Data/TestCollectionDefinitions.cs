﻿using Xunit;

namespace YourNamespace.Tests
{
    public class SequentialCollection1Definition
    {
        [CollectionDefinition("ProfileControllerTestCollection", DisableParallelization = true)]
        public class ProfileControllerTestCollection { }
    }
}