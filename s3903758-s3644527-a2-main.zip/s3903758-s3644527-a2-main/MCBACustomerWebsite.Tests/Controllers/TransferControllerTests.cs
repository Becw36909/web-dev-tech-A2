﻿using MCBACustomerWebsite.Controllers;
using MCBACustomerWebsite.Tests.Fixtures;
using MCBACustomerWebsite.ViewModels;
using Microsoft.AspNetCore.Mvc;
using Xunit;
using MCBACustomerWebsite.Data;
using MCBACustomerWebsite.Tests.Data;
using MCBACustomerWebsite.Models;

using SimpleHashing.Net;
using Microsoft.AspNetCore.Http;

namespace MCBACustomerWebsite.Tests.Controllers
{
    public class TransferControllerTests : IClassFixture<SqliteTestFixture>
    {
        private McbaContext _Context;
        private TransferController Controller;
        private int defaultCustomerID { get; } = 1000;
        private decimal _transferSurcharge = 0.10m;

        public TransferControllerTests(SqliteTestFixture fixture)
        {
            _Context = fixture.CreateContext();
            Controller = new TransferController(_Context);
            Controller.TempData = new MockTempData();
        }

        [Fact]
        public async void Create_ReturnView_WithViewModel()
        {
            Controller.ControllerContext.HttpContext = MockHttpContext.Create(defaultCustomerID);

            // Act
            var result = Controller.Create();

            // Assert a view result
            var viewResult = Assert.IsType<ViewResult>(result);

            Assert.Equal("create", viewResult.ViewName);
            // Assert that the View Model exists
            var model = Assert.IsAssignableFrom<TransferViewModel>(viewResult.ViewData.Model);
            // Assert that the view model has an array of accounts
            Assert.IsAssignableFrom<List<Account>>(model.Accounts);
            // Assert that the view model has the account number
            Assert.IsAssignableFrom<int>(model.AccountNumber);
        }



        [Theory]
        [InlineData(1200, 1201, 50.50, "First Test")] // All Data
        [InlineData(1200, 1201, 5, null)] // No comment
        public async void Confirm_Success_ReturnConfirmView_WithViewModel(int AccountNumber, int DestinationAccountNumber, decimal Amount, string Comment)
        {
            Controller.ControllerContext.HttpContext = MockHttpContext.Create(defaultCustomerID);

            TransferViewModel TransferViewModel = new TransferViewModel
            {
                AccountNumber = AccountNumber,
                DestinationAccountNumber = DestinationAccountNumber,
                Amount = Amount,
                Comment = Comment
            };

            // Act
            var result = await Controller.Confirm(TransferViewModel);

            // Assert correct view
            var viewResult = Assert.IsType<ViewResult>(result);
            Assert.Equal("confirm", viewResult.ViewName);
            // Assert Transaction View Model
            var model = Assert.IsAssignableFrom<TransferViewModel>(viewResult.ViewData.Model);
            Assert.IsAssignableFrom<int>(model.AccountNumber);
            Assert.IsAssignableFrom<decimal>(model.Amount);

        }

        

        [Theory]
        [InlineData(null, 1210, 50.50, "First Test")] // No Account number
        [InlineData(1210, null, 50.50, "First Test")] // No Transfer to
        [InlineData(9191, 1210, 50.50, "First Test")] // Account number not found
        [InlineData(1210, 1211, 0, null)] // No Amount
        [InlineData(1210, 1211, -100, null)] // Negative Amount
        [InlineData(1210, 1211, 10.123, null)] // more than two digits in amount
        [InlineData(1210, 1211, 10.123, null)] // Comment with too many characters
        [InlineData(1210, 1211, 50, "BAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA")] // 31 characters in comment
        [InlineData(1211, 1210, 1001, null)] // Amount > Account Balance
        [InlineData(1211, 1210, 701, null)] // Balance - Amount < Required balance amount
        public async void Confirm_Fail_ReturnCreateView_WithErrors(int AccountNumber, int DestinationAccountNumber, decimal Amount, string Comment)
        {
            Controller.ControllerContext.HttpContext = MockHttpContext.Create(defaultCustomerID);

            TransferViewModel TransferViewModel = new TransferViewModel
            {
                AccountNumber = AccountNumber,
                DestinationAccountNumber = DestinationAccountNumber,
                Amount = Amount,
                Comment = Comment
            };

            // Act
            var result = await Controller.Confirm(TransferViewModel);
            // Returns to create screen
            var viewResult = Assert.IsType<ViewResult>(result);
            Assert.Equal("create", viewResult.ViewName);
            // Assert errors on view models.
            Assert.True(Controller.ModelState.ErrorCount > 0);
        }

        [Theory]
        [InlineData(1200, 1201, 50.50, "First Test")] // All Data
        [InlineData(1200, 1201, 5, null)] // No comment
        public async void Store_Success_RedirectToIndex_WithSuccess(int AccountNumber, int DestinationAccountNumber, decimal Amount, string Comment)
        {
            Controller.ControllerContext.HttpContext = MockHttpContext.Create(defaultCustomerID);

            decimal surcharge = 0;

            // Get current Transfer From Details
            Account TransferFrom_Account = _Context.Accounts.Find(AccountNumber);
            decimal TransferFrom_Balance = TransferFrom_Account.Balance;
            // Get current Transfer Destination Details
            Account TransferTo_Account = _Context.Accounts.Find(DestinationAccountNumber);
            decimal TransferTo_Balance = TransferTo_Account.Balance;

            // Check to see if there is a surcharge
            if (TransferFrom_Account.SurchargeCheck(_Context, AccountNumber) > 2)
            {
                surcharge = _transferSurcharge;
            }

            TransferViewModel TransferViewModel = new TransferViewModel
            {
                AccountNumber = AccountNumber,
                DestinationAccountNumber = DestinationAccountNumber,
                Amount = Amount,
                Comment = Comment
            };

            // Act
            var result = await Controller.Store(TransferViewModel);

            // Assert correct view
            // Assert redirection to Home.Index with success message
            var redirect = Assert.IsType<RedirectToActionResult>(result);
            Assert.Equal("Home", redirect.ControllerName);
            Assert.Equal("Index", redirect.ActionName);
            Assert.True(Controller.TempData["Success"] != null);

            // Assert that the old balance has been decremented by the amount
            Account Updated_TransferFrom = _Context.Accounts.Find(AccountNumber);
            decimal new_expected_balance = TransferFrom_Balance -= (Amount + surcharge);
            Assert.Equal(new_expected_balance, Updated_TransferFrom.Balance);

            // Assert that the destination account has been incremented by the amount
            Account Updated_Account = _Context.Accounts.Find(DestinationAccountNumber);
            decimal new_TransferTo_Balance = TransferTo_Balance += (Amount);
            Assert.Equal(new_TransferTo_Balance, Updated_Account.Balance);

        }

        [Theory]
        [InlineData(null, 1210, 50.50, "First Test")] // No Account number
        [InlineData(1210, null, 50.50, "First Test")] // No Transfer to
        [InlineData(9191, 1210, 50.50, "First Test")] // Account number not found
        [InlineData(1210, 1211, 0, null)] // No Amount
        [InlineData(1210, 1211, -100, null)] // Negative Amount
        [InlineData(1210, 1211, 10.123, null)] // more than two digits in amount
        [InlineData(1210, 1211, 10.123, null)] // Comment with too many characters
        [InlineData(1210, 1211, 50, "BAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA")] // 31 characters in comment
        [InlineData(1211, 1210, 1001, null)] // Amount > Account Balance
        [InlineData(1211, 1210, 701, null)] // Balance - Amount < Required balance amount
        public async void Store_Fail_ReturnCreateView_WithErrors(int AccountNumber, int DestinationAccountNumber, decimal Amount, string Comment)
        {
            Controller.ControllerContext.HttpContext = MockHttpContext.Create(defaultCustomerID);

            TransferViewModel TransferViewModel = new TransferViewModel
            {
                AccountNumber = AccountNumber,
                DestinationAccountNumber = DestinationAccountNumber,
                Amount = Amount,
                Comment = Comment
            };

            // Act
            var result = await Controller.Confirm(TransferViewModel);
            // Returns to create screen
            var viewResult = Assert.IsType<ViewResult>(result);
            Assert.Equal("create", viewResult.ViewName);
            // Assert errors on view models.
            Assert.True(Controller.ModelState.ErrorCount > 0);
        }

    }
}
