﻿using MCBACustomerWebsite.Controllers;
using MCBACustomerWebsite.Tests.Fixtures;
using MCBACustomerWebsite.ViewModels;
using Microsoft.AspNetCore.Mvc;
using Xunit;
using MCBACustomerWebsite.Data;
using MCBACustomerWebsite.Tests.Data;
using MCBACustomerWebsite.Models;

using SimpleHashing.Net;
using Microsoft.AspNetCore.Http;

namespace MCBACustomerWebsite.Tests.Controllers
{
    public class StatementControllerTests : IClassFixture<SqliteTestFixture>
    {
        private McbaContext _Context;
        private StatementController Controller;
        private int defaultCustomerID { get; } = 1;

        public StatementControllerTests(SqliteTestFixture fixture)
        {
            _Context = fixture.CreateContext();
            Controller = new StatementController(_Context);
            Controller.TempData = new MockTempData();
        }

        [Fact]
        public async void Indexs_ReturnView_WithViewModel()
        {
            // Arrange
            Controller.ControllerContext.HttpContext = MockHttpContext.Create(defaultCustomerID);

            // Act
            var result = await Controller.Index();

            // Assert that a view is returned
            var viewResult = Assert.IsType<ViewResult>(result);
            // Assert that a customer model is returned
            var model = Assert.IsType<MyStatementViewModel>(viewResult.Model);
            // Assert that Accounts is a list
            Assert.IsType<List<Account>>(model.Accounts);


        }

        [Theory]
        [InlineData(1000, null)] // Valid Account - No Page Number
        [InlineData(1000, 1)] // Valid Account - Page #1
        [InlineData(1000, 2)] // Valid Account - Page #2
        [InlineData(1000, 9999)] // Valid Account - Absurd page number
        public async void Display_Success_ReturnView_WithViewModel(int AccountNumber, int? page = 1)
        {
            // Arrange
            Controller.ControllerContext.HttpContext = MockHttpContext.Create(defaultCustomerID);

            // Act
            var result = await Controller.Display(AccountNumber,page);

            // Assert that a view is returned
            var viewResult = Assert.IsType<ViewResult>(result);
            Assert.Equal("Display", viewResult.ViewName);
            // Assert that a customer model is returned
            var model = Assert.IsType<MyStatementViewModel>(viewResult.Model);


        }

        [Theory]
        [InlineData(null, null)] // No Account
        [InlineData(100, 1)] // Invalid Account Number
        public async void Display_Fail_ReturnView_WithViewModel(int AccountNumber, int? page = 1)
        {
            // Arrange
            Controller.ControllerContext.HttpContext = MockHttpContext.Create(defaultCustomerID);

            // Act
            var result = await Controller.Display(AccountNumber, page);

            var redirect = Assert.IsType<RedirectToActionResult>(result);
            Assert.Equal("Index", redirect.ActionName);
            Assert.True(Controller.TempData["Error"] != null);



        }
    }
}
