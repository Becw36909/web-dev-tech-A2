﻿using MCBACustomerWebsite.Controllers;
using MCBACustomerWebsite.Tests.Fixtures;
using MCBACustomerWebsite.ViewModels;
using Microsoft.AspNetCore.Mvc;
using Xunit;
using MCBACustomerWebsite.Data;
using MCBACustomerWebsite.Tests.Data;
using MCBACustomerWebsite.Models;

using SimpleHashing.Net;
using Microsoft.AspNetCore.Http;
using System.Globalization;

namespace MCBACustomerWebsite.Tests.Controllers
{
    [Collection("ProfileControllerTestCollection")]
    public class BillpayControllerTests : IClassFixture<SqliteTestFixture>
    {
        private McbaContext _Context;
        private BillpayController Controller;
        private int defaultCustomerID { get; } = 1;

        public BillpayControllerTests(SqliteTestFixture fixture)
        {
            _Context = fixture.CreateContext();
            Controller = new BillpayController(_Context);
            Controller.TempData = new MockTempData();
        }

        [Fact]
        public void Index_ReturnView_WithViewModel()
        {
            // Arrange
            Controller.ControllerContext.HttpContext = MockHttpContext.Create(defaultCustomerID);

            // Act
            var result = Controller.Index();

            // Assert a view result
            var viewResult = Assert.IsType<ViewResult>(result);
            Assert.Equal("Index", viewResult.ViewName);
            // Assert that the View Model exists
            var model = Assert.IsAssignableFrom<BillPayViewModel>(viewResult.ViewData.Model);
            // Assert that the view model has an array of accounts
            Assert.IsAssignableFrom<List<Account>>(model.Accounts);
            // Assert that the view model has an array of Billpays
            Assert.IsAssignableFrom<List<BillPay>>(model.BillPays);

        }

        [Fact]
        public void Create_ReturnView_WithViewModel()
        {
            Controller.ControllerContext.HttpContext = MockHttpContext.Create(defaultCustomerID);

            // Act
            var result = Controller.Create();

            // Assert a view result
            var viewResult = Assert.IsType<ViewResult>(result);
            Assert.Equal("create", viewResult.ViewName);
            // Assert that the View Model exists
            var model = Assert.IsAssignableFrom<BillPayViewModel>(viewResult.ViewData.Model);
            // Assert that the view model has an array of accounts
            Assert.IsAssignableFrom<List<Account>>(model.Accounts);
            // Assert that the view model has an array of Billpays
            Assert.IsAssignableFrom<List<Payee>>(model.Payees);
        }

        [Theory]
        [InlineData(1)]
        public async void Cancel_Success_ReturnsSuccess(int BillpayID)
        {
            Controller.ControllerContext.HttpContext = MockHttpContext.Create(defaultCustomerID);

            // Act
            var result = await Controller.Cancel(BillpayID);

            // Assert redirect with Success
            var viewResult = Assert.IsType<RedirectToActionResult>(result);
            Assert.True(Controller.TempData["Success"] != null);
            //Assert.True(Controller.TempData["Success"] != null);

            // Assert that billpay has been deleted
            BillPay bill = _Context.BillPays.Find(BillpayID);
            Assert.Equal(null, bill);
        }

        [Theory]
        [InlineData(null)]
        [InlineData(999)]
        public async void Cancel_Failed_ReturnsError(int BillpayID)
        {
            Controller.ControllerContext.HttpContext = MockHttpContext.Create(defaultCustomerID);

            // Act
            var result = await Controller.Cancel(BillpayID);

            // Assert redirect with Success
            var viewResult = Assert.IsType<RedirectToActionResult>(result);
            Assert.True(Controller.TempData["Error"] != null);

            // Assert that billpay has been deleted
            BillPay bill = _Context.BillPays.Find(BillpayID);
            Assert.Equal(null, bill);
        }

        [Theory]
        [InlineData(1000, 1, 5, "M", "2023-12-20 15:30:00")]
        [InlineData(1000, 1, 50, "O", "2024-08-20 15:30:00")]
        [InlineData(1000, 1, 0.01, "M", "2024-08-20 15:30:00")] 
        [InlineData(1000, 1, 5000, "O", "2024-08-20 15:30:00")]
        public async void Store_Success_RedirectWithSuccess(int AccountNumber, int PayeeID, decimal Amount, string Period, string Time)
        {
            Controller.ControllerContext.HttpContext = MockHttpContext.Create(defaultCustomerID);

            DateTime parseTime = DateTime.ParseExact(Time, "yyyy-MM-dd HH:mm:ss", CultureInfo.InvariantCulture);

            BillPayViewModel ViewModel = new BillPayViewModel
            {
                AccountNumber = AccountNumber,
                PayeeID = PayeeID,
                Amount = Amount,
                Period = Period,
                ScheduleTimeUtc = parseTime
            };

            // Act
            var result = await Controller.Store(ViewModel);

            // Assert that the customer is redirected with success message
            var viewResult = Assert.IsType<RedirectToActionResult>(result);
            Assert.True(Controller.TempData["Success"] != null);
            // Assert that there's no errors
            Assert.True(Controller.ModelState.ErrorCount == 0);

            // Get new record from database
            BillPay Bill = _Context.BillPays.FirstOrDefault(
                bp => bp.AccountNumber == AccountNumber && 
                bp.PayeeID == PayeeID 
                && bp.Amount == Amount);
            // Assert that new record is not null
            Assert.IsType<BillPay>(Bill);

        }

        [Theory]
        [InlineData(null, 1, 5, "O", "03-03-2024")] // No Account
        [InlineData(5, 1, 5, "O", "03-03-2024")] // Account not found
        [InlineData(1000, 2, 5, "O", "03-03-2024")] // Payee not found
        [InlineData(1000, 1, 0, "O", "03-03-2024")] // Transfer amount is 0.
        [InlineData(1000, 1, 5, "M", "2022-12-20 15:30:00")] // Date is in the past
        [InlineData(1000, 1, 5, "T", "2024-12-20 15:30:00")] // Period is invalid
        [InlineData(1000, 1, 5.1234, "T", "2024-12-20 15:30:00")] // More than two decimal places
        public async void Store_Fail_ReturnViewWithErrors(int AccountNumber, int PayeeID, decimal Amount, string Period, DateTime Time )
        {
            Controller.ControllerContext.HttpContext = MockHttpContext.Create(defaultCustomerID);

            BillPayViewModel ViewModel = new BillPayViewModel
            {
                AccountNumber = AccountNumber,
                PayeeID = PayeeID,
                Amount = Amount,
                Period = Period,
                ScheduleTimeUtc = Time
            };

            // Act
            var result = await Controller.Store(ViewModel);

            // Assert that the edit view result is returned
            var viewResult = Assert.IsType<ViewResult>(result);
            Assert.Equal("create", viewResult.ViewName);
            // Assert that there are errors returned
            Assert.True(Controller.ModelState.ErrorCount > 0);
        }

        [Theory]
        [InlineData(10)] // Failed Bpay for 5
        public async void Retry_Success_RedirectWithSuccess(int BillpayID)
        {
            Controller.ControllerContext.HttpContext = MockHttpContext.Create(defaultCustomerID);

            // Act
            var result = await Controller.Retry(BillpayID);


            // Assert redirect with Success
            var viewResult = Assert.IsType<RedirectToActionResult>(result);
            Assert.True(Controller.TempData["Success"] != null);

            //var tempDataSuccess = Controller.TempData.Peek("Success");
            //Assert.NotNull(tempDataSuccess); // Check that TempData has "Success" key
        }

        [Theory]
        [InlineData(null)]
        [InlineData(3)] // Billpay for an amount larger than the balance
        [InlineData(4)] // Blocked Billpay
        [InlineData(5)] // Completed Billpay
        [InlineData(6)] // Invalid amount due to remaining Checking balance >= 300
        public async void Retry_Fail_RedirectWithError(int BillpayID)
        {
            Controller.ControllerContext.HttpContext = MockHttpContext.Create(defaultCustomerID);
            // Act
            var result = await Controller.Retry(BillpayID);

            // Assert redirect with Success
            var viewResult = Assert.IsType<RedirectToActionResult>(result);
            Assert.True(Controller.TempData["Error"] != null);

        }




    }
}
