using MCBACustomerWebsite.Controllers;
using MCBACustomerWebsite.Tests.Fixtures;
using MCBACustomerWebsite.ViewModels;
using Microsoft.AspNetCore.Mvc;
using Xunit;
using MCBACustomerWebsite.Data;
using MCBACustomerWebsite.Tests.Data;
using MCBACustomerWebsite.Models;

using SimpleHashing.Net;
using Microsoft.AspNetCore.Http;

namespace MCBACustomerWebsite.Tests.Controllers
{

    [Collection("ProfileControllerTestCollection")]
    public class ProfileControllerTests : IClassFixture<SqliteTestFixture>
    {
        private McbaContext _Context;
        private ProfileController Controller;
        private int defaultCustomerID { get; } = 1;

        public ProfileControllerTests(SqliteTestFixture fixture)
        {
            _Context = fixture.CreateContext();
            Controller = new ProfileController(_Context);
            Controller.TempData = new MockTempData();
        }

        [Fact]
        public void Index_FindLoggedInUser_ReturnView()
        {
            // Arrange
            int CustomerID = 1;
            Controller.ControllerContext.HttpContext = MockHttpContext.Create(CustomerID);

            // Act
            var result = Controller.Index();

            // Assert a view result
            var viewResult = Assert.IsType<ViewResult>(result);
            // Assert that the View Model exists
            var model = Assert.IsAssignableFrom<ProfileIndexViewModel>(viewResult.ViewData.Model);
            // Assert that character model exists.
            Assert.NotNull(model.Customer);
            // Assert that the character model retrieved matches the one requested
            Assert.Equal(CustomerID, model.Customer.CustomerID);

        }

        [Fact]
        public void Edit_ReturnView_WithCustomer()
        {
            // Arrange
            int CustomerID = 1;
            Controller.ControllerContext.HttpContext = MockHttpContext.Create(CustomerID);

            // Act
            var result = Controller.Edit();

            // Assert that the edit view result is returned
            var viewResult = Assert.IsType<ViewResult>(result);
            Assert.Equal("edit", viewResult.ViewName);
            // Assert that the View Model exists
            var model = Assert.IsAssignableFrom<ProfileEditViewModel>(viewResult.ViewData.Model);
            // Assert that character model exists.
            Assert.IsType<Customer>(model.Customer);
            // Assert that View has access to StateOptions Dictionary
            Assert.IsType<Dictionary<String,String>>(model.StateOptions);
            // Assert that the character model retrieved matches the one requested
            Assert.Equal(CustomerID, model.Customer.CustomerID);

        }

        /* 
        * Test Update function with Valid Data
        */
        [Theory]
        [InlineData(1,"Doe John","Abbey Road","Sydney","2000","NSW","123 123 123","0400 000 000")] // All valid values
        [InlineData(1, "John Doe", null, null, null, null, null, null)] // Required values only
        [InlineData(1, "A", "A", "A", "1234", "NT", "111 111 111", "0400 000 000")] //Test Minimum character inputs
        [InlineData(1, TestData.ch50, TestData.ch50, TestData.ch40, "1234", "NSW", "111 111 111", "0400 000 000")] //Test Maximum character inputs
        public async void UpdateProfile_Success_RedirectToIndex(int CustomerID, string Name, string Address, String City, String PostCode, String State, String TFN, String MobileNumber)
        {
            // Arrange
            Controller.ControllerContext.HttpContext = MockHttpContext.Create(CustomerID);

            ProfileEditViewModel ViewModel = new ProfileEditViewModel
            {
                Customer = new Customer
                {
                    CustomerID = CustomerID,
                    Name = Name,
                    Address = Address,
                    City = City,
                    PostCode = PostCode,
                    State = State,
                    TFN = TFN,
                    MobileNumber = MobileNumber
                }
            };

            // Act
            var result = await Controller.Update(ViewModel);

            // Assert to redirect to Index upon success
            var redirect = Assert.IsType<RedirectToActionResult>(result);
            Assert.Equal("index", redirect.ActionName);

            // Get the customer model after it has been updated.
            Customer Customer = _Context.Customers.Find(CustomerID);
            // Assert that the Customer details have updated
            Assert.Equal(CustomerID, Customer.CustomerID);
            Assert.Equal(Name, Customer.Name);
            Assert.Equal(Address, Customer.Address);
            Assert.Equal(City, Customer.City);
            Assert.Equal(PostCode, Customer.PostCode);
            Assert.Equal(State, Customer.State);
            Assert.Equal(TFN, Customer.TFN);
            Assert.Equal(MobileNumber, Customer.MobileNumber);

        }

        /* 
         * Test Update function with Invalid Data
         */
        [Theory]
        [InlineData(1, null, null, null, null, null, null, null)] // No Username
        [InlineData(1, TestData.ch51, TestData.ch41, TestData.ch51, TestData.ch51, TestData.ch51, TestData.ch51, TestData.ch51)] // max+1 character input
        [InlineData(1, "John Doe", null, null, null, "ABCD", null, null)] // Postcode Is not letters
        [InlineData(1, "John Doe", null, null, null, "123", null, null)] // Postcode that is not exactly 4 digits
        [InlineData(1, "John Doe", null, null, null, null, "1111 111 11", null)] // Incorrect TFN format
        [InlineData(1, "John Doe", null, null, null, null, null, "03 020 303 30")] // Incorrect mobile format

        public async void UpdateProfile_Fail_ReturnViewWithErrors(int CustomerID, string Name, string Address, String City, String PostCode, String State, String TFN, String MobileNumber)
        {
            // Arrange
            Controller.ControllerContext.HttpContext = MockHttpContext.Create(CustomerID);

            ProfileEditViewModel ViewModel = new ProfileEditViewModel
            {
                Customer = new Customer
                {
                    CustomerID = CustomerID,
                    Name = Name,
                    Address = Address,
                    City = City,
                    PostCode = PostCode,
                    State = State,
                    TFN = TFN,
                    MobileNumber = MobileNumber
                }
            };

            // Act
            var result = await Controller.Update(ViewModel);


            // Assert that the edit view result is returned
            var viewResult = Assert.IsType<ViewResult>(result);
            Assert.Equal("edit", viewResult.ViewName);

        }

        [Theory]
        [InlineData(1,"abc123","Password","Password")]
        public async void UpdatePassword_Success_RedirectToIndex(int CustomerID, string Password, string NewPassword, string ConfirmNewPassword)
        {
            // Arrange
            ISimpleHash SimpleHash = new SimpleHash(); 
            Controller.ControllerContext.HttpContext = MockHttpContext.Create(CustomerID);

            ProfileIndexViewModel ViewModel = new ProfileIndexViewModel
            {
                Password = Password,
                NewPassword = NewPassword,
                ConfirmNewPassword = ConfirmNewPassword
            };

            // Act
            var result = await Controller.UpdatePassword(ViewModel);


            // Assert that the Password has been updated in the Database.
            Login Login = _Context.Logins.FirstOrDefault(login => login.CustomerID == CustomerID);
            bool Match_NewPassword = SimpleHash.Verify(NewPassword, Login.PasswordHash);
            Assert.True(Match_NewPassword);

            Assert.True(Controller.TempData["Success"] != null);
        }

        [Theory]
        
        [InlineData(1, "abc123", null, null)] // No New password or Confirm New Password
        [InlineData(1, null, "Password", "Password")] // No Current Password
        [InlineData(1, "123abc", "Password", "Password")] // Current password does not match database value
        [InlineData(1, "abc123", "Pass", "Word")] // NewPassword and Confirm New Password does not match

        public async void UpdatePassword_Fail_ReturnViewWithErrors(int CustomerID, string Password, string NewPassword, string ConfirmNewPassword)
        {
            Controller.ControllerContext.HttpContext = MockHttpContext.Create(CustomerID);

            ProfileIndexViewModel ViewModel = new ProfileIndexViewModel
            {
                Password = Password,
                NewPassword = NewPassword,
                ConfirmNewPassword = ConfirmNewPassword
            };

            // Act
            var result = await Controller.UpdatePassword(ViewModel);


            // Assert that the edit view result is returned
            var viewResult = Assert.IsType<ViewResult>(result);
            Assert.Equal("show", viewResult.ViewName);
        }

        [Fact]
        public async void UploadProfilePicture_ReturnWithSuccess()
        {

            
            Controller.ControllerContext.HttpContext = MockHttpContext.Create(defaultCustomerID);


            byte[] imageData;
            using (var httpClient = new HttpClient())
            {
                string imageUrl = "https://webprojectuni.s3.ap-southeast-2.amazonaws.com/profile_placeholder.jpg";
                imageData = await httpClient.GetByteArrayAsync(imageUrl);
            }

            // Create an IFormFile instance from the image data
            var fileName = "profile_placeholder.jpg";
            var contentType = "image/jpg";
            var fakeFile = new FormFile(new MemoryStream(imageData), 0, imageData.Length, fileName, fileName)
            {
                Headers = new HeaderDictionary(),
                ContentType = contentType
            };


            var result = await Controller.UploadProfilePicture(fakeFile);

            // Assert Response Type
            var Action = Assert.IsType<RedirectToActionResult>(result);

            Customer Customer = _Context.Customers.Find(defaultCustomerID);

            Assert.NotNull(Customer.ProfileImage);

        }

        [Fact]
        public async void UploadProfilePicture_Fail_WithError()
        {

            Controller.ControllerContext.HttpContext = MockHttpContext.Create(defaultCustomerID);

            // Clear any existing Profile Picture
            await Controller.DeleteProfilePicture();

            var emptyStream = Array.Empty<byte>();
            var fileName = "empty_file.txt";
            var contentType = "test/plain";

            var fakeFile = new FormFile(new MemoryStream(emptyStream), 0, 0, fileName, fileName)
            {
                Headers = new HeaderDictionary(),
                ContentType = contentType
            };


            var result = await Controller.UploadProfilePicture(fakeFile);

            // Assert Response Type
            var Action = Assert.IsType<RedirectToActionResult>(result);
            Assert.True(Controller.TempData["Error"] != null);

            // Assert that Customer image is still null
            Customer Customer = _Context.Customers.Find(1);
            Assert.Equal(null, Customer.ProfileImage);



        }

        [Fact]
        public async void DeleteProfilePicture_ReturnWithSuccessMessage()
        {
            int CustomerID = 1;

            Controller.ControllerContext.HttpContext = MockHttpContext.Create(CustomerID);

            var result = await Controller.DeleteProfilePicture();

            // Assert redirect to Index
            var viewResult = Assert.IsType<RedirectToActionResult>(result);
            Assert.True(Controller.TempData["Success"] != null);

            // Assert that the customer image is now null
            Customer Customer = _Context.Customers.Find(1);
            Assert.Equal(null, Customer.ProfileImage);

        }


        [Fact]
        public void GetProfileImage()
        {
            // Arrange
            Controller.ControllerContext.HttpContext = MockHttpContext.Create(defaultCustomerID);

            // Act
            var result = Controller.GetProfileImage() as FileResult;


            // Assert that the content type is returned
            var Action = Assert.IsType<FileContentResult>(result);
            //Assert.Equal("image/jpg", result.ContentType);

        }
    }
}