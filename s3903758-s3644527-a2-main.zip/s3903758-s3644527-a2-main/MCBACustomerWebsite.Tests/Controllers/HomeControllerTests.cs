﻿using MCBACustomerWebsite.Controllers;
using MCBACustomerWebsite.Tests.Fixtures;
using MCBACustomerWebsite.ViewModels;
using Microsoft.AspNetCore.Mvc;
using Xunit;
using MCBACustomerWebsite.Data;
using MCBACustomerWebsite.Tests.Data;
using MCBACustomerWebsite.Models;

using SimpleHashing.Net;
using Microsoft.AspNetCore.Http;

namespace MCBACustomerWebsite.Tests.Controllers
{
    public class HomeControllerTests : IClassFixture<SqliteTestFixture>
    {
        private readonly McbaContext _Context;
        private HomeController Controller;
        private int defaultCustomerID { get; } = 1;

        public HomeControllerTests(SqliteTestFixture fixture)
        {
            _Context = fixture.CreateContext();
            Controller = new HomeController(_Context);
        }

        [Fact]
        public async void Index_ReturnView_WithCustomer()
        {
            // Arrange
            Controller.ControllerContext.HttpContext = MockHttpContext.Create(defaultCustomerID);

            // Act
            var result = await Controller.Index();

            // Assert that a view is returned
            var viewResult = Assert.IsType<ViewResult>(result);
            // Assert that a customer model is returned
            var model = Assert.IsType<Customer>(viewResult.Model);
            // Asser that the customer model is the logged in customer
            Assert.Equal(defaultCustomerID, model.CustomerID);

        }
    }
}
