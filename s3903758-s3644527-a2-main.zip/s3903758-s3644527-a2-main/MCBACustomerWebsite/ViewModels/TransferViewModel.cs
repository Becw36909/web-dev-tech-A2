﻿using MCBACustomerWebsite.Models;

namespace MCBACustomerWebsite.ViewModels
{
    public class TransferViewModel
    {

        public List<Account> Accounts { get; set; }
        public int AccountNumber { get; set; }
        public int DestinationAccountNumber { get; set; }
        public decimal Amount { get; set; }
        public string Comment { get; set; }

    }
}
