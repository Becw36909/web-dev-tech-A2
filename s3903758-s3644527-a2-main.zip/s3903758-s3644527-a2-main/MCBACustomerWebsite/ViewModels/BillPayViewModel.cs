﻿using MCBACustomerWebsite.Models;

namespace MCBACustomerWebsite.ViewModels
{
    public class BillPayViewModel
    {
        public List<Account> Accounts { get; set; }
        public List<Payee> Payees { get; set; }
        public List<BillPay> BillPays { get; set; }
        public int AccountNumber { get; set; }
        public int PayeeID { get; set; }
        public decimal Amount { get; set; }
        public string Period { get; set; } = "O";
        public DateTime ScheduleTimeUtc { get; set; }

    }
}
