﻿using MCBACustomerWebsite.Models;
using X.PagedList;

namespace MCBACustomerWebsite.ViewModels
{
    public class MyStatementViewModel
    {
        public List<Account> Accounts { get; set; }
        public Account Account { get; set; }
        public int AccountNumber { get; set; }
        public IPagedList<Transaction> PagedList { get; set; }

    }
}
