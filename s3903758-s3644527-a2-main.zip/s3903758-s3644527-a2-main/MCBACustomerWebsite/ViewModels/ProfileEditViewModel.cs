﻿using MCBACustomerWebsite.Models;

namespace MCBACustomerWebsite.ViewModels
{
    public class ProfileEditViewModel
    {
        public Customer Customer { get; set; }
        public Dictionary<string, string> StateOptions { get; set; }
    }
}
