﻿using MCBACustomerWebsite.Models;
using Microsoft.AspNetCore.Identity;
using Microsoft.SqlServer.Server;

namespace MCBACustomerWebsite.Data;

public static class SeedData
{
    public static async Task InitializeAsync(IServiceProvider serviceProvider)
    {
        var context = serviceProvider.GetRequiredService<McbaContext>();

        // Look for customers.
        if (context.Customers.Any())
            return; // DB has already been seeded.

        RestAPIRequest apiRequest = new RestAPIRequest();
        // Add to customer List
        List<Customer> customers = await apiRequest.GetAPIRequestAsync();

        foreach ( Customer customer in customers )
        {

            // Update Logins with CustomerID
            customer.Login.CustomerID = customer.CustomerID;

            // Set Active Property to True
            customer.Active = true;

            foreach (var account in customer.Accounts)
            {
                foreach (var transaction in account.Transactions)
                {
                    // First loop over transactions to get the account balance
                    transaction.SetAccountNumber(account.AccountNumber);
                    // Set all initial transaction types as Deposit
                    transaction.TransactionType = TransactionType.Deposit;

                    // Calculate Account Balance
                    account.CalculateInitialBalance(transaction);
                }
            }
        }

        // Add Test Customer
        customers.Add(new Customer
        {
            CustomerID = 2400,
            Name = "Test Customer",
            Address = "Test Address",
            City = "Test City",
            PostCode = "1234",
            State = "NSW",
            TFN = "111 111 111",
            MobileNumber = "0410 000 000",
            Active = true,
            Login = new Login
            {
                LoginID = "87654321",
                CustomerID = 2400,
                PasswordHash = "Rfc2898DeriveBytes$50000$MrW2CQoJvjPMlynGLkGFrg==$x8iV0TiDbEXndl0Fg8V3Rw91j5f5nztWK1zu7eQa0EE="
            },
            Accounts = new List<Account>
            {
                new Account
                {
                    AccountNumber = 4400,
                    AccountType = "S",
                    CustomerID = 2400,
                    Balance = 1000,
                    Transactions = new List<Transaction>(),
                    BillPays = new List<BillPay>()
                }
            }
        });

        context.Customers.AddRange(customers);
        
        context.SaveChanges();
    }
}
