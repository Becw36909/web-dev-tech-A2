﻿using MCBACustomerWebsite.Models;
using Newtonsoft.Json;

namespace MCBACustomerWebsite.Data;

public class RestAPIRequest
{

    public async Task<List<Customer>> GetAPIRequestAsync()
    {
        const string Url = "https://coreteaching01.csit.rmit.edu.au/~e103884/wdt/services/customers/";

        // Contact webservice.
        using var client = new HttpClient();
        var json = await client.GetStringAsync(Url);


        // Convert JSON string to Customer objects.
        var customers = JsonConvert.DeserializeObject<List<Customer>>(json, new JsonSerializerSettings
        {
            // See here for DateTime format string documentation:
            // https://learn.microsoft.com/en-au/dotnet/standard/base-types/custom-date-and-time-format-strings
            DateFormatString = "dd/MM/yyyy"
            // the below line was shown in the A2 demo code
            // DateFormatString = "dd/MM/yyyy hh:mm:ss tt"
        });

        return customers;
    }
}
