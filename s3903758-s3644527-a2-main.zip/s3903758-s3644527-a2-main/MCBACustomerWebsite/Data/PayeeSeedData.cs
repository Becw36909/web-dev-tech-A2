﻿using MCBACustomerWebsite.Models;


namespace MCBACustomerWebsite.Data;

public class PayeeSeedData
{
    public static async Task InitializeAsync(IServiceProvider serviceProvider)
    {
        var context = serviceProvider.GetRequiredService<McbaContext>();

        // Look for payees.
        if (context.Payees.Any())
            return; // DB has already been seeded.

        context.Payees.AddRange(
            new Payee
            {
                Name = "Optus",
                Address = "123 Fake Street",
                City = "Melbourne",
                PostCode = "3000",
                State = "VIC",
                Phone = "(03) 4156 5660"
            },
            new Payee
            {
                Name = "Energex",
                Address = "21 Energy Street",
                City = "Sydney",
                PostCode = "2000",
                State = "NSW",
                Phone = "(02) 5887 1122"
            },
            new Payee
            {
                Name = "Wags Veterinary",
                Address = "8 Bark Road",
                City = "Brisbane",
                PostCode = "4000",
                State = "QLD",
                Phone = "(07) 3205 8902"
            });

        context.SaveChanges();

    }
}
