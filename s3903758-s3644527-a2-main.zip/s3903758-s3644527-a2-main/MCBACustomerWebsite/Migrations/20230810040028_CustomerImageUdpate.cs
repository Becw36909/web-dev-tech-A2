﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace MCBACustomerWebsite.Migrations
{
    /// <inheritdoc />
    public partial class CustomerImageUdpate : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropCheckConstraint(
                name: "CH_Login_LoginID",
                table: "Logins");

            migrationBuilder.DropCheckConstraint(
                name: "CH_Login_PasswordHash",
                table: "Logins");

            migrationBuilder.AddCheckConstraint(
                name: "CH_Login_LoginID",
                table: "Logins",
                sql: "length(LoginID) = 8");

            migrationBuilder.AddCheckConstraint(
                name: "CH_Login_PasswordHash",
                table: "Logins",
                sql: "length(PasswordHash) = 94");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropCheckConstraint(
                name: "CH_Login_LoginID",
                table: "Logins");

            migrationBuilder.DropCheckConstraint(
                name: "CH_Login_PasswordHash",
                table: "Logins");

            migrationBuilder.AddCheckConstraint(
                name: "CH_Login_LoginID",
                table: "Logins",
                sql: "len(LoginID) = 8");

            migrationBuilder.AddCheckConstraint(
                name: "CH_Login_PasswordHash",
                table: "Logins",
                sql: "len(PasswordHash) = 94");
        }
    }
}
