﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace MCBACustomerWebsite.Migrations
{
    /// <inheritdoc />
    public partial class ChangeCustomerImageDatatype : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.RenameColumn(
                name: "Image",
                table: "Customers",
                newName: "ImageData");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.RenameColumn(
                name: "ImageData",
                table: "Customers",
                newName: "Image");
        }
    }
}
