﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using MCBACustomerWebsite.Utilities.Session;

namespace MCBACustomerWebsite.Filters;

public class AuthorizeCustomerAttribute : Attribute, IAuthorizationFilter
{
    public void OnAuthorization(AuthorizationFilterContext context)
    {
        if(context.HttpContext.Session.IsAnonymous())
            context.Result = new RedirectToActionResult("Login", "Login", null);
    }
}
