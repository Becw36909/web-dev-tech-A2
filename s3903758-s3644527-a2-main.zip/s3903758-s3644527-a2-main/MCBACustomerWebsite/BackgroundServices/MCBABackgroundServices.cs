﻿using MCBACustomerWebsite.Data;
using MCBACustomerWebsite.Models;
using Microsoft.EntityFrameworkCore;


namespace MCBACustomerWebsite.BackgroundServices
{
    public class MCBABackgroundServices : BackgroundService
    {

        private readonly IServiceProvider _services;
        private readonly ILogger<MCBABackgroundServices> _logger;

        public MCBABackgroundServices(IServiceProvider services, ILogger<MCBABackgroundServices> logger)
        {
            _services = services;
            _logger = logger;
        }

        protected override async Task ExecuteAsync(CancellationToken cancellationToken)
        {
            _logger.LogInformation("MCBA Background Service is running.");

            while (!cancellationToken.IsCancellationRequested)
            {
                await DoBillPayAsync(cancellationToken);

                _logger.LogInformation("MCBA Background Service is waiting a minute.");

                await Task.Delay(TimeSpan.FromMinutes(1), cancellationToken);
            }
        }

        private async Task DoBillPayAsync(CancellationToken cancellationToken)
        {
            _logger.LogInformation("MCBA Background Service is working.");

            using var scope = _services.CreateScope();
            var context = scope.ServiceProvider.GetRequiredService<McbaContext>();

            // Logic goes below to deal with a BillPay
            var billPays = await context.BillPays.Where(x => x.State == State.Pending).ToListAsync(cancellationToken);
            DateTime currentTime = DateTime.UtcNow;
            foreach (var billPay in billPays)
            {
                //_logger.LogInformation("Inside the foreach loop.");
                //_logger.LogInformation("Inside the foreach loop. List count of " + billPays.Count);
                //_logger.LogInformation(billPay.ScheduleTimeUtc + " " + DateTime.UtcNow);
                //_logger.LogInformation(billPay.ScheduleTimeUtc + " " + currentTime.ToLocalTime());

                //if (billPay.ScheduleTimeUtc < DateTime.UtcNow)
                if (billPay.ScheduleTimeUtc < currentTime.ToLocalTime())

                {
                    //_logger.LogInformation("inside the if statement for comparing time.");

                    Account account = context.Accounts.Find(billPay.AccountNumber);
                    if (!SufficientBalanceCheck(billPay, account))
                    {
                        billPay.State = State.Failed;
                    }
                    else
                    {
                        //_logger.LogInformation("inside the else if a payment has not failed.");

                        await account.StoreBillPayWithdrawal(context, billPay);

                        billPay.State = State.Completed;

                        if (billPay.Period == "M")
                        {
                            //_logger.LogInformation("in if statement updating monthly bills.");

                            context.BillPays.Add(new BillPay
                            {
                                AccountNumber = billPay.AccountNumber,
                                PayeeID = billPay.PayeeID,
                                Amount = billPay.Amount,
                                ScheduleTimeUtc = billPay.ScheduleTimeUtc.AddMonths(1),
                                Period = billPay.Period,
                                State = State.Pending,
                            }); ;
                        }
                    }
                }
            }

            await context.SaveChangesAsync(cancellationToken);

            _logger.LogInformation("MCBA Background Service work complete.");
        }


        private bool SufficientBalanceCheck(BillPay billPay, Account account)
        {
            bool isBalanceAvailable = false;
            if (billPay.Amount <= account.CalculateAvailableBalance())
            {
                isBalanceAvailable = true;
            }
            return isBalanceAvailable;
        }
    }
}
