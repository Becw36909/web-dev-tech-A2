using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace MCBACustomerWebsite.Views.Profile
{
    public class editModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
