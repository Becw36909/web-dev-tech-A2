using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace MCBACustomerWebsite.Views.Billpay
{
    public class createModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
