using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace MCBACustomerWebsite.Views.Deposit
{
    public class confirmModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
