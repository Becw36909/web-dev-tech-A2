using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace MCBACustomerWebsite.Views.Deposit
{
    public class createModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
