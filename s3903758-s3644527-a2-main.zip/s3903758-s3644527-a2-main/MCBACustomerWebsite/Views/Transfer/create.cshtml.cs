using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace MCBACustomerWebsite.Views.Transfer
{
    public class createModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
