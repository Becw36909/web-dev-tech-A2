using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace MCBACustomerWebsite.Views.Transfer
{
    public class confirmModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
