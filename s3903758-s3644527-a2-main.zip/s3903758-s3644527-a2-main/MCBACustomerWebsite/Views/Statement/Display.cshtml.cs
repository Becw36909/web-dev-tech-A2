using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace MCBACustomerWebsite.Views.Statement
{
    public class listModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
