using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace MCBACustomerWebsite.Views.Statement
{
    public class IndexModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
