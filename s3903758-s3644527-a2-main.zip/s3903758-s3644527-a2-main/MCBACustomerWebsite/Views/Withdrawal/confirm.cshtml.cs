using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace MCBACustomerWebsite.Views.Withdrawal
{
    public class confirmModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
