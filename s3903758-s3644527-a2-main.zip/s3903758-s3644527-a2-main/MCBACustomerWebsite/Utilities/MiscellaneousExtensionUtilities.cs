﻿namespace MCBACustomerWebsite.Utilities;

public static class MiscellaneousExtensionUtilities
{
    public static bool HasMoreThanNDecimalPlaces(this decimal value, int n) => decimal.Round(value, n) != value;
    public static bool HasMoreThanTwoDecimalPlaces(this decimal value) => value.HasMoreThanNDecimalPlaces(2);

    public static bool IsInRange(this int value, int min, int max) => value >= min && value <= max;

}
