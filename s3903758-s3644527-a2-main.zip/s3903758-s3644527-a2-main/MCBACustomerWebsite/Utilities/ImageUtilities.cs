﻿using ImageMagick;

namespace MCBACustomerWebsite.Utilities
{
    public class ImageUtilities
    {

        public static MagickGeometry CalculateResize(MagickImage Image, int TargetWidth, int TargetHeight)
        {

            // Determine the largest dimension
            int maxDimension = Math.Max(Image.Width, Image.Height);

            // Calculate the aspect ratio
            double aspectRatio = (double)Image.Width / Image.Height;

            // Set the target size
            if (aspectRatio > 1)
            {
                TargetWidth = 400;
                TargetHeight = (int)(TargetWidth / aspectRatio);
            }
            else
            {
                TargetHeight = 400;
                TargetWidth = (int)(TargetHeight * aspectRatio);
            }


            return new MagickGeometry(TargetWidth, TargetHeight);

        }

    }
}
