﻿using Microsoft.CodeAnalysis.CSharp.Syntax;

namespace MCBACustomerWebsite.Utilities.Session
{
    public static class SessionUtils
    {
        private const string SessionKey_CustomerID = "CustomerID";

        public static int? GetCustomerID(this ISession session) => 
            session.GetInt32(SessionKey_CustomerID);

        public static void SetCustomerID(this ISession session, int customerID) => 
            session.SetInt32(SessionKey_CustomerID, customerID);

        private const string SessionKey_CustomerName = "Name";

        public static string GetCustomerName(this ISession session) => 
            session.GetString(SessionKey_CustomerName);

        public static void SetCustomerName(this ISession session, string name) =>
            session.SetString(SessionKey_CustomerName, name);

        public static bool IsLoggedIn(this ISession session) => GetCustomerID(session).HasValue;

        public static bool IsAnonymous(this ISession session) => !session.IsLoggedIn();

    }
}
