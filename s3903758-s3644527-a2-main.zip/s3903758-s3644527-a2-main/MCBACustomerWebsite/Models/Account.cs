﻿using MCBACustomerWebsite.Data;
using MCBACustomerWebsite.ViewModels;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace MCBACustomerWebsite.Models;

public class Account
{
    [Key, DatabaseGenerated(DatabaseGeneratedOption.None)]
    [Display(Name = "Account Number")]
    [Required]
    public int AccountNumber { get; set; }

    [Display(Name = "Type")]
    public string AccountType { get; set; }

    public int CustomerID { get; set; }
    public virtual Customer Customer { get; set; }

    [Column(TypeName = "money"), DataType(DataType.Currency)]
    public decimal Balance { get; set; }

    // Set ambiguous navigation property with InverseProperty annotation or Fluent-API in the McbaContext.cs file.
    [InverseProperty("Account")]
    public virtual List<Transaction> Transactions { get; set; }

    // Set ambiguous navigation property with InverseProperty annotation or Fluent-API in the McbaContext.cs file.
    [InverseProperty("Account")]
    public virtual List<BillPay> BillPays { get; set; }

    private decimal _checkingAccountMinBalance = 300;


    private static readonly Dictionary<string, string> AccountTypeMap = new Dictionary<string, string>()
    {
        { "S", "Savings" },
        { "C", "Checking" }
    };

    public string GetAccountType()
    {
        return (AccountTypeMap.ContainsKey(AccountType)) ? AccountTypeMap[this.AccountType] : AccountType;
    }

    // Calculate initial balance using Deposit Transactions only from Seeder
    public decimal CalculateInitialBalance(Transaction transaction)
    {
        Balance += transaction.Amount;

        return Balance;
    }

    [DataType(DataType.Currency)]
    public decimal CalculateAvailableBalance()
    {
        decimal availableBalance;

        if (AccountType == "S")
        {
            availableBalance = Balance;
        }
        else
        {
            availableBalance = Balance - _checkingAccountMinBalance;
        }
        return availableBalance;
    }

    // Check if a Surcharge needs to be applied
    public int SurchargeCheck(McbaContext _context, int AccountNumber)
    {
        // change surcharge to be a database count instead of getting all transactions in the Account model
        int transactionTypeCheck = 0;
        Transactions = _context.Transactions.Where(a => a.AccountNumber == AccountNumber).ToList();

        foreach (Transaction transaction in Transactions)
        {
            if (transaction.TransactionType == TransactionType.Withdraw)
            {
                transactionTypeCheck++;
            }
            else if (transaction.TransactionType == TransactionType.Transfer &&
                transaction.DestinationAccountNumber != null)
            {
                transactionTypeCheck++;
            }
        }

        return transactionTypeCheck;

    }

    // Store A Deposit transaction
    public async Task StoreDeposit(McbaContext _context, decimal Amount, string Comment)
    {

        this.Balance += Amount;
        // Create Transaction
        this.Transactions.Add(
            new Transaction
            {
                TransactionType = TransactionType.Deposit,
                Amount = Amount,
                Comment = Comment,
                TransactionTimeUtc = DateTime.UtcNow
            });

        // Save Transaction to database.
        await _context.SaveChangesAsync();

        return;
    }

    // Store A Withdrawal transaction
    public async Task StoreWithdrawal(McbaContext _context, decimal Amount, string Comment)
    {

        this.Balance -= Amount;
        // Create Transaction
        this.Transactions.Add(
            new Transaction
            {
                TransactionType = TransactionType.Withdraw,
                Amount = Amount,
                Comment = Comment,
                TransactionTimeUtc = DateTime.UtcNow
            });

        // Save Transaction to database.
        await _context.SaveChangesAsync();

        return;
    }

    // Store A BillPay Withdrawal transaction
    public async Task StoreBillPayWithdrawal(McbaContext _context, BillPay billPay)
    {

        this.Balance -= billPay.Amount;
        // Create Transaction
        this.Transactions.Add(
            new Transaction
            {
                TransactionType = TransactionType.BillPay,
                Amount = billPay.Amount,
                TransactionTimeUtc = DateTime.UtcNow
            });

        // Save Transaction to database.
        await _context.SaveChangesAsync();

        return;
    }

    // Store an outgoing Transfer transaction
    public async Task StoreOutgoingTransfer(McbaContext _context, decimal Amount, string Comment, int DestinationAccount)
    {

        this.Balance -= Amount;
        // Create Transaction
        this.Transactions.Add(
            new Transaction
            {
                TransactionType = TransactionType.Transfer,
                DestinationAccountNumber = DestinationAccount,
                Amount = Amount,
                Comment = Comment,
                TransactionTimeUtc = DateTime.UtcNow
            });

        // Save Transaction to database.
        await _context.SaveChangesAsync();

        return;
    }

    // Store incoming Transfer transaction
    public async Task StoreTransferDeposit(McbaContext _context, decimal Amount, string Comment)
    {

        this.Balance += Amount;
        // Create Transaction
        this.Transactions.Add(
            new Transaction
            {
                TransactionType = TransactionType.Transfer,
                Amount = Amount,
                Comment = Comment,
                TransactionTimeUtc = DateTime.UtcNow
            });

        // Save Transaction to database.
        await _context.SaveChangesAsync();

        return;
    }

    // Store Surcharge Transaction
    public async Task StoreSurcharge(McbaContext _context, decimal Amount)
    {

        this.Balance -= Amount;
        // Create Transaction
        this.Transactions.Add(
            new Transaction
            {
                TransactionType = TransactionType.ServiceCharge,
                Amount = Amount,
                TransactionTimeUtc = DateTime.UtcNow
            });

        // Save Transaction to database.
        await _context.SaveChangesAsync();

        return;
    }
}
