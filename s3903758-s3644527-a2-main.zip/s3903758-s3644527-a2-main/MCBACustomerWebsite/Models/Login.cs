﻿using MCBACustomerWebsite.Data;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using SimpleHashing.Net;

namespace MCBACustomerWebsite.Models;

public class Login
{
    [Column(TypeName = "char")]
    [Required]
    [StringLength(8, MinimumLength = 8, ErrorMessage = "LoginID must be exactly 8 characters.")]
    public string LoginID { get; set; }

    public int CustomerID { get; set; }
    public virtual Customer Customer { get; set; }

    [Column(TypeName = "char")]
    [Required, StringLength(94)]
    public string PasswordHash { get; set; }


    // Store A Password
    public async Task UpdatePassword(McbaContext _context, string NewPassword)
    {
        ISimpleHash SimpleHash = new SimpleHash();

        this.PasswordHash = SimpleHash.Compute(NewPassword);

        // Save Password to database.
        await _context.SaveChangesAsync();

        return;
    }
}
