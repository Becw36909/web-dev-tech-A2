﻿using System.ComponentModel.DataAnnotations;

namespace MCBACustomerWebsite.Models;

public class Payee
    {

    public int PayeeId { get; set; }

    [Required, StringLength(50)]
    public string Name { get; set; }

    [Required, StringLength(50)]
    public string Address { get; set; }

    [Required, StringLength(40)]
    public string City { get; set; }

    [Required, StringLength(4)]
    public string PostCode { get; set; }

    [Required, StringLength(3)]
    public string State { get; set; }

    [RegularExpression(@"^\(0[1-9]\) \d{4} \d{4}$", ErrorMessage = "Invalid phone number format. Correct format: (0X) XXXX XXXX")]
    [Required, StringLength(14)]
    public string Phone { get; set; }


    public static readonly Dictionary<string, string> StateMap = new Dictionary<string, string>()
    {
        { "ACT", "Australian Capital Territory" },
        { "NSW", "New South Wales" },
        { "NT", "Northern Territory" },
        { "QLD", "Queensland" },
        { "SA", "South Australia" },
        { "TAS", "Tasmania" },
        { "WA", "Western Australia" },
        { "VIC", "Victoria" },

    };

    public string GetStateName()
    {
        return (State != null && StateMap.ContainsKey(State)) ? StateMap[this.State] : "";

    }
}

