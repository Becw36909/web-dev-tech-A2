﻿using MCBACustomerWebsite.Models;
using MCBACustomerWebsite.ViewModels;
using Microsoft.AspNetCore.Mvc.ModelBinding;
using SimpleHashing.Net;

namespace MCBACustomerWebsite.Validators
{
    public class ValidatePasswordUpdate
    {
        public static bool Validate(ProfileIndexViewModel viewModel, ModelStateDictionary ModelState, Login Login)
        {
            bool isValid = true;
            bool varified;

            // Confirm that Current password, NewPassword and Confirm new password are not empty.
            if(viewModel.Password == null)
            {
                ModelState.AddModelError(nameof(viewModel.Password), "You must enter your existing password.");
                return false;
            }

            // Check to see that the Login has successfully been found.
            if(Login == null)
            {
                ModelState.AddModelError(nameof(viewModel.Password), "User Login cannot be found.");
                return false;
            }
            
            // Check to see if there is a New Password value, and if so then check that the Confirm Password matches.
            if (viewModel.NewPassword == null)
            {
                ModelState.AddModelError(nameof(viewModel.NewPassword), "You must enter a new password.");
                isValid = false;
            }
            else if (viewModel.NewPassword != viewModel.ConfirmNewPassword)
            {
                ModelState.AddModelError(nameof(viewModel.ConfirmNewPassword), "Please ensure this matches the New Password input.");
                isValid = false;
            }


            // Confirm current password
            varified = new SimpleHash().Verify(viewModel.Password, Login.PasswordHash);
            if(!varified)
            {
                ModelState.AddModelError(nameof(viewModel.Password), "This does not match your current existing password.");
                isValid = false;
            }

            return isValid;
        }
    }
}
