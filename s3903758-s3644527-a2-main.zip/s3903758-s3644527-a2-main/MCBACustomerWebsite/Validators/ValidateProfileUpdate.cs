﻿using MCBACustomerWebsite.Migrations;
using MCBACustomerWebsite.Models;
using MCBACustomerWebsite.ViewModels;
using Microsoft.AspNetCore.Mvc.ModelBinding;
using System.Text.RegularExpressions;

namespace MCBACustomerWebsite.Validators
{
    public class ValidateProfileUpdate
    {

        public static bool Validate(ProfileEditViewModel viewModel, ModelStateDictionary ModelState)
        {
            Customer Input = viewModel.Customer;
            bool validationCheck = true;


            // Validate Name Input
            if(Input.Name == null || Input.Name.Length < 0 || Input.Name.Length > 50)
            {
                ModelState.AddModelError(nameof(viewModel.Customer.Name), 
                    "A profile name must be between 0 and 50 characters long.");
                validationCheck = false;
            }
            // Validate Address Input
            if(Input.Address != null && Input.Address.Length > 50)
            {
                ModelState.AddModelError(nameof(viewModel.Customer.Address), 
                    "The address cannot be greater than 50 characters long.");
                validationCheck = false;
            }
            // Validate Postcode Input
            if(Input.PostCode != null && Input.PostCode.Length > 4)
            {
                ModelState.AddModelError(nameof(viewModel.Customer.PostCode), 
                    "The Postcode cannot be greater than 4 characters long.");
                validationCheck = false;
            }
            // Validate State Input
            if(Input.State != null && Input.State.Length > 3)
            {
                ModelState.AddModelError(nameof(viewModel.Customer.State), 
                    "The state cannot be greater than 3 characters long.");
                validationCheck = false;
            }

            // State has to be either blank or one of the choices in the statemap.
            if (Input.State != null && !Customer.StateMap.ContainsKey(Input.State)){
                ModelState.AddModelError(nameof(viewModel.Customer.State),
                    "Must be a valid State of Australia.");
                validationCheck = false;
            }

            if(Input.TFN != null && !Regex.IsMatch(Input.TFN, @"^\d{3} \d{3} \d{3}$"))
            {
                ModelState.AddModelError(nameof(viewModel.Customer.TFN), "The TFC must be in the format XXX XXX XXX");
                validationCheck = false;
            }

            if (Input.MobileNumber != null && !Regex.IsMatch(Input.MobileNumber, @"^04\d{2} \d{3} \d{3}$"))
            {
                ModelState.AddModelError(nameof(viewModel.Customer.MobileNumber), "The Mobile number must be in the format 04XX XXX XXX");
                validationCheck = false;
            }

            return validationCheck;
        }

    }
}
