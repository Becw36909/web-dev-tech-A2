﻿using MCBACustomerWebsite.Data;
using MCBACustomerWebsite.Models;
using MCBACustomerWebsite.Utilities;
using MCBACustomerWebsite.ViewModels;
using Microsoft.AspNetCore.Mvc.ModelBinding;

namespace MCBACustomerWebsite.Validators
{
    public class ValidateDeposit
    {
        public const decimal MinTransactionAmount = 0;
        public const int AllowedCommentLength = 30;

        public static bool Validate(TransactionViewModel viewModel, ModelStateDictionary ModelState, McbaContext _context)
        {
            bool validationCheck = true;

            Account account = _context.Accounts.Find(viewModel.AccountNumber);

            if (account == null)
            {
                ModelState.AddModelError(nameof(viewModel.AccountNumber), "Please choose an account from the list.");
                return false;
            }
            if (viewModel.Amount <= MinTransactionAmount)
            {
                ModelState.AddModelError(nameof(viewModel.Amount), "The amount must be greater than zero.");
                validationCheck = false;
            }

            if (viewModel.Amount.HasMoreThanTwoDecimalPlaces())
            {
                ModelState.AddModelError(nameof(viewModel.Amount), "The amount must be a valid amount to two decimal places.");
                validationCheck = false;
            }

            if (viewModel.Comment != null && viewModel.Comment.Length > AllowedCommentLength)
            {
                ModelState.AddModelError(nameof(viewModel.Comment), "Comment cannot be longer than 30 characters.");
                validationCheck = false;
            }


            return validationCheck;
        }
    }
}
