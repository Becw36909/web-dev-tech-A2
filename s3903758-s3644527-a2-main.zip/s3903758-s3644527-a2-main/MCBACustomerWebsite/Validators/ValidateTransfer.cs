﻿using MCBACustomerWebsite.Data;
using MCBACustomerWebsite.Models;
using MCBACustomerWebsite.Utilities;
using MCBACustomerWebsite.ViewModels;
using Microsoft.AspNetCore.Mvc.ModelBinding;

namespace MCBACustomerWebsite.Validators
{
    public class ValidateTransfer
    {
        public const decimal MinTransactionAmount = 0;
        public const int AllowedCommentLength = 30;


        public static bool Validate(TransferViewModel viewModel, ModelStateDictionary ModelState, 
            McbaContext _context, decimal _transferSurcharge)
        {
            bool validationCheck = true;

            Account account = _context.Accounts.Find(viewModel.AccountNumber);
            Account destinationAccount = _context.Accounts.Find(viewModel.DestinationAccountNumber);
            decimal surcharge = 0;

            // Check for any surcharges
            if (account != null) {
                int surchargeCheck = account.SurchargeCheck(_context, account.AccountNumber);
                if (surchargeCheck > 2)
                {
                    surcharge = _transferSurcharge;
                }
            }

            if (account == null)
            {
                ModelState.AddModelError(nameof(viewModel.AccountNumber), "Please choose an account from the list.");
                return false;
            }

            if (destinationAccount == account)
            {
                ModelState.AddModelError(nameof(viewModel.DestinationAccountNumber), "Cannot transfer money to the same account.");
                validationCheck = false;
            }

            if (destinationAccount == null)
            {
                ModelState.AddModelError(nameof(viewModel.DestinationAccountNumber), "This account number cannot be found.");
                validationCheck = false;
            }

            if (viewModel.Amount <= MinTransactionAmount)
            {
                ModelState.AddModelError(nameof(viewModel.Amount), "The amount must be greater than zero.");

                validationCheck = false;
            }

            if (viewModel.Amount > account.CalculateAvailableBalance() - surcharge)
            {
                ModelState.AddModelError(nameof(viewModel.Amount), "Not enough balance available for this transaction.");
                validationCheck = false;
            }

            if (viewModel.Amount.HasMoreThanTwoDecimalPlaces())
            {
                ModelState.AddModelError(nameof(viewModel.Amount), "The amount must be a valid amount to two decimal places.");

                validationCheck = false;
            }

            // check comment length, would prefer to use the data annotation on comment but its not working 
            // as property is not required
            if (viewModel.Comment != null && viewModel.Comment.Length > AllowedCommentLength)
            {
                ModelState.AddModelError(nameof(viewModel.Comment), "Comment cannot be longer than 30 characters.");
                validationCheck = false;
            }

            return validationCheck;
        }
    }
}

