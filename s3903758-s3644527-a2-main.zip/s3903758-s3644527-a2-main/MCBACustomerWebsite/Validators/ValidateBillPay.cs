﻿using MCBACustomerWebsite.Data;
using MCBACustomerWebsite.Migrations;
using MCBACustomerWebsite.Models;
using MCBACustomerWebsite.Utilities;
using MCBACustomerWebsite.ViewModels;
using Microsoft.AspNetCore.Mvc.ModelBinding;
using System.Text.RegularExpressions;

namespace MCBACustomerWebsite.Validators
{
    public class ValidateBillPay
    {
        public const decimal MinTransactionAmount = 0;
        private const string ExpectedDateFormat = "dd/MM/yyyy hh:mm:ss tt";

        public static bool Validate(BillPayViewModel viewModel, ModelStateDictionary ModelState,
            McbaContext _context)
        {
            bool validationCheck = true;

            DateTime currentTime = DateTime.UtcNow;


            Account account = _context.Accounts.Find(viewModel.AccountNumber);
            Payee payee = _context.Payees.Find(viewModel.PayeeID);

            if (account == null)
            {
                ModelState.AddModelError(nameof(viewModel.AccountNumber), "Please choose an account from the list.");
            }

            if (payee == null)
            {
                ModelState.AddModelError(nameof(viewModel.PayeeID), "Please choose a Payee from the list.");
            }
            


            if ( viewModel.Amount == null || viewModel.Amount <= MinTransactionAmount )
            {
                ModelState.AddModelError(nameof(viewModel.Amount), "The amount must be greater than zero.");
            }

            if (viewModel.Amount.HasMoreThanTwoDecimalPlaces())
            {
                ModelState.AddModelError(nameof(viewModel.Amount), "The amount must be a valid amount to two decimal places.");
            }

            if (viewModel.ScheduleTimeUtc < currentTime.ToLocalTime())
            {
                ModelState.AddModelError(nameof(viewModel.ScheduleTimeUtc), "Schedule time must be in the future");
            }

            if (viewModel.Period == null || !Regex.IsMatch(viewModel.Period, "^(O|M)$"))
            {
                ModelState.AddModelError(nameof(viewModel.Period), "A valid period must be selected");
            }

            // Can we replace the validationcheck = false with just this check?
            if(ModelState.ErrorCount > 0)
            {
                validationCheck = false;
            }


            return validationCheck;
        }
    }
}
