﻿using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using MCBACustomerWebsite.Models;
using MCBACustomerWebsite.Filters;
using MCBACustomerWebsite.Data;
using Microsoft.EntityFrameworkCore;
using MCBACustomerWebsite.Utilities.Session;


namespace MCBACustomerWebsite.Controllers;

// Bonus Material: Implement global authorisation check.
[AuthorizeCustomer]
public class HomeController : Controller
{
    private readonly McbaContext _context;

    public HomeController(McbaContext context) => _context = context;

    private int _customerID => HttpContext.Session.GetCustomerID().Value;


    public async Task<ViewResult> Index()
    {

        // Eager loading.
        var customer = await _context.Customers.Include(x => x.Accounts).
            FirstOrDefaultAsync(x => x.CustomerID == _customerID);

        return View(customer);
    }

    //public IActionResult Index() => View();

    [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
    public IActionResult Error() =>
        View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
}
