﻿using MCBACustomerWebsite.Data;
using MCBACustomerWebsite.Filters;
using MCBACustomerWebsite.Utilities.Session;
using MCBACustomerWebsite.ViewModels;
using Microsoft.AspNetCore.Mvc;
using X.PagedList;

namespace MCBACustomerWebsite.Controllers
{
    [AuthorizeCustomer]
    public class StatementController : Controller
    {
        private readonly McbaContext _context;

        public StatementController(McbaContext context) => _context = context;

        private int _customerID => HttpContext.Session.GetCustomerID().Value;

        public async Task<ViewResult> Index()
        {
            var Accounts = _context.Accounts.Where(a => a.CustomerID == _customerID).ToList();

            return View(new MyStatementViewModel { Accounts = Accounts });
        }


        public async Task<IActionResult> Display( int AccountNumber, int? page = 1)
        {

            // Get Account
            var account = _context.Accounts.Find(AccountNumber);
            // Validate Account
            if (account == null || account.CustomerID != _customerID)
            {
                TempData["Error"] = "Selected account cannot be found. Please check account details and try again.";
                return RedirectToAction(nameof(Index));

            }

            // Page the transactions, maximum of 4 per page.
            const int pageSize = 4;

            var pagedList = await _context.Transactions.Where(x => x.AccountNumber == AccountNumber).
                OrderByDescending(x => x.TransactionTimeUtc).ToPagedListAsync(page, pageSize);

            MyStatementViewModel viewModel = new MyStatementViewModel
            {
                AccountNumber = AccountNumber,
                Account = account,
                PagedList = pagedList,

            };

            return View("Display", viewModel);

        }
    }
}
