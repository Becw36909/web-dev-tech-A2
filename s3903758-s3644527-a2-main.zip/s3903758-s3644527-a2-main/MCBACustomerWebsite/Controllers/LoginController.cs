﻿using Microsoft.AspNetCore.Mvc;
using MCBACustomerWebsite.Data;
using MCBACustomerWebsite.Models;
using SimpleHashing.Net;
using MCBACustomerWebsite.Utilities.Session;

namespace MCBACustomerWebsite.Controllers;

// Bonus Material: Implement global authorisation check.
//[AllowAnonymous]
// Default routing is not used with the below line - so the url contains the below instead of /Login/Login
[Route("/Mcba/SecureLogin")]
public class LoginController : Controller
{
    private static readonly ISimpleHash s_simpleHash = new SimpleHash();

    private readonly McbaContext _context;

    public LoginController(McbaContext context) => _context = context;

    public IActionResult Login() => View();

    [HttpPost]
    // viewModel for the below is BETTER
    public async Task<IActionResult> Login(string loginID, string password)
    {
        var login = await _context.Logins.FindAsync(loginID); // null or a single Login returned
        if(login == null || string.IsNullOrEmpty(password) || !s_simpleHash.Verify(password, login.PasswordHash))
        { 
            ModelState.AddModelError("LoginFailed", "Login failed, please try again.");
            return View(new Login { LoginID = loginID });
        }

        Customer Customer = _context.Customers.Find(login.CustomerID);

        if(Customer.Active == false)
        {
            ModelState.AddModelError("LoginFailed", "Account Locked, please call customer support.");
            return View(new Login { LoginID = loginID });
        }


        // Login customer.
        HttpContext.Session.SetCustomerID(login.CustomerID);
        HttpContext.Session.SetCustomerName(login.Customer.Name);

        return RedirectToAction("Index", "Home");
    }

    [Route("Logout")]
    public IActionResult Logout()
    {
        // Logout customer.
        HttpContext.Session.Clear();

        return Redirect("/Mcba/SecureLogin");
    }
}
