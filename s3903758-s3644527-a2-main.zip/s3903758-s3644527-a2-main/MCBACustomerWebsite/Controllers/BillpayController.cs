﻿using MCBACustomerWebsite.Data;
using MCBACustomerWebsite.Filters;
using MCBACustomerWebsite.Models;
using MCBACustomerWebsite.Utilities.Session;
using MCBACustomerWebsite.Validators;
using MCBACustomerWebsite.ViewModels;
using Microsoft.AspNetCore.Mvc;
using Microsoft.CodeAnalysis;
using Microsoft.EntityFrameworkCore;
using System.Diagnostics;
using X.PagedList;

namespace MCBACustomerWebsite.Controllers
{
    [AuthorizeCustomer]
    public class BillpayController : Controller
    {
        public BillpayController(McbaContext context) => _context = context;

        private readonly McbaContext _context;
        private int _customerID => HttpContext.Session.GetCustomerID().Value;

        public List<BillPay> billPays = new List<BillPay>();

        public IActionResult Index()
        {
            var Accounts = _context.Accounts.Where(a => a.CustomerID == _customerID).ToList();

            foreach (var account in Accounts)
            {
                var billPaysForAccount = _context.BillPays.Where(a => a.AccountNumber == account.AccountNumber).ToList();
                billPays.AddRange(billPaysForAccount);
            }

            // below line is not ordering properly - ordering by account number as well as time
            billPays = billPays.OrderBy(x => x.ScheduleTimeUtc).ToList();

            return View("Index", new BillPayViewModel { Accounts = Accounts, BillPays = billPays});
        }

        public IActionResult Create()
        {
            List<Account> Accounts = _context.Accounts.Where(a => a.CustomerID == _customerID).ToList();

            List<Payee> Payees = _context.Payees.ToList();

            return View("create", new BillPayViewModel
            {
                Accounts = Accounts, 
                Payees = Payees,
                ScheduleTimeUtc = DateTime.UtcNow
            });
        }


        [HttpPost]
        public async Task<IActionResult> Cancel(int? billPayID)
        {

            var billPay = await _context.BillPays.FindAsync(billPayID);

            if(billPay == null)
            {
                TempData["Error"] = $"Bill does not exist.";
                return RedirectToAction("Index", "BillPay");
            }

            _context.BillPays.Remove(billPay);
            await _context.SaveChangesAsync();
            // Success Flash Message
            TempData["Success"] = $"Bill has been successfully deleted from your schedule.";

            // Return to homepage
            return RedirectToAction("Index", "BillPay");

        }

        [HttpPost]
        public async Task<IActionResult> Store(BillPayViewModel viewModel)
        {
            // Validate Form
            bool valid = ValidateBillPay.Validate(viewModel, ModelState, _context);
            // If invalid return errors.
            if (!valid)
            {
                viewModel.Accounts = _context.Accounts.Where(a => a.CustomerID == _customerID).ToList();
                viewModel.Payees = _context.Payees.ToList();
                return View("create", viewModel);
            }

            _context.BillPays.Add(
                new BillPay
                {
                    AccountNumber = viewModel.AccountNumber,
                    PayeeID = viewModel.PayeeID,
                    Amount = viewModel.Amount,
                    ScheduleTimeUtc = viewModel.ScheduleTimeUtc,
                    Period = viewModel.Period,
                    State = State.Pending,
                });

            // Save Scheduled BillPay to database.
            await _context.SaveChangesAsync();

            // Success Flash Message
            TempData["Success"] = $"New payment has successfully been scheduled.";
            // Return to homepage
            return RedirectToAction("Index", "BillPay");
        }

        public async Task<IActionResult> Retry(int id)
        {

            BillPay Bill = _context.BillPays.Find(id);

            if(Bill == null)
            {
                TempData["Error"] = "This Bill cannot be found. Please check details and try again.";
                return RedirectToAction("Index", "BillPay");
            }

            State updated = await Bill.ProcessPayment(_context);

            if(updated == State.Completed)
            {
                TempData["Success"] = "Billpay payment has successfully been processed.";
            }
            else {
                TempData["Error"] = "This payment cannot be processed. Please check account balance and try again.";
            }

            return RedirectToAction("Index", "BillPay");

        }

    }
}
