﻿using Microsoft.AspNetCore.Mvc;
using MCBACustomerWebsite.Filters;
using MCBACustomerWebsite.Data;
using MCBACustomerWebsite.Utilities.Session;
using MCBACustomerWebsite.ViewModels;
using MCBACustomerWebsite.Validators;
using MCBACustomerWebsite.Models;
using Microsoft.EntityFrameworkCore;

namespace MCBACustomerWebsite.Controllers
{
    [AuthorizeCustomer]
    public class DepositController : Controller
    {

        private readonly McbaContext _context;

        public DepositController(McbaContext context) => _context = context;

        private int _customerID => HttpContext.Session.GetCustomerID().Value;

        public  IActionResult Create()
        {
            var Accounts =  _context.Accounts.Where(a => a.CustomerID == _customerID).ToList();

            return View("create", new TransactionViewModel{ Accounts = Accounts });
        }


        [HttpPost]
        public async Task<IActionResult> Confirm(TransactionViewModel viewModel)
        {
            // Validate Form
            bool valid = ValidateDeposit.Validate(viewModel, ModelState, _context);
            // If invalid return errors.
            if (!valid)
            {
                viewModel.Accounts = _context.Accounts.Where(a => a.CustomerID == _customerID).ToList();
                return View("create", viewModel);
            }


            return View("confirm", new TransactionViewModel
            {
                AccountNumber = viewModel.AccountNumber,
                Amount = viewModel.Amount,
                Comment = viewModel.Comment,
            });

        }


        [HttpPost]
        public async Task<IActionResult> Store(TransactionViewModel viewModel)
        {
            // Validate Form
            bool valid = ValidateDeposit.Validate(viewModel,ModelState, _context);
            // If invalid return errors.
            if(!valid) 
            {
                viewModel.Accounts = _context.Accounts.Where(a => a.CustomerID == _customerID).ToList();
                return View("create", viewModel);
            }

            // Get Account
            Account account = _context.Accounts.Include(a => a.Transactions).FirstOrDefault(a => a.AccountNumber == viewModel.AccountNumber);
            

            // Create the deposit
            await account.StoreDeposit(_context, viewModel.Amount,viewModel.Comment);

            // Success Flash Message
            TempData["Success"] = $"${viewModel.Amount} has been successfully deposited into {account.GetAccountType()}.";
            // Return to homepage
            return RedirectToAction("Index", "Home");
        }

    }
}
