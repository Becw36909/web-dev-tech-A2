﻿using Microsoft.AspNetCore.Mvc;
using MCBACustomerWebsite.Filters;
using MCBACustomerWebsite.Data;
using MCBACustomerWebsite.Utilities.Session;
using MCBACustomerWebsite.ViewModels;
using MCBACustomerWebsite.Validators;

namespace MCBACustomerWebsite.Controllers
{
    [AuthorizeCustomer]
    public class WithdrawalController : Controller
    {

        private readonly McbaContext _context;

        public WithdrawalController(McbaContext context) => _context = context;

        private int _customerID => HttpContext.Session.GetCustomerID().Value;

        private decimal _withdrawSurcharge = 0.05m;


        public async Task<IActionResult> Create()
        {
            var Accounts = _context.Accounts.Where(a => a.CustomerID == _customerID).ToList();

            return View("create", new TransactionViewModel { Accounts = Accounts });
        }


        [HttpPost]
        public async Task<IActionResult> Confirm(TransactionViewModel viewModel)
        {

            // Validate Form
            bool valid = ValidateWithdrawal.Validate(viewModel, ModelState, _context, _withdrawSurcharge);
            // If invalid return errors.
            if (!valid)
            {
                viewModel.Accounts = _context.Accounts.Where(a => a.CustomerID == _customerID).ToList();
                return View("create", viewModel);
            }


            return View("confirm", new TransactionViewModel
            {
                AccountNumber = viewModel.AccountNumber,
                Amount = viewModel.Amount,
                Comment = viewModel.Comment,
            });

        }


        [HttpPost]
        public async Task<IActionResult> Store(TransactionViewModel viewModel)
        {

            // Validate Form
            bool valid = ValidateWithdrawal.Validate(viewModel, ModelState, _context, _withdrawSurcharge);
            // If invalid return errors.
            if (!valid)
            {
                viewModel.Accounts = _context.Accounts.Where(a => a.CustomerID == _customerID).ToList();
                return View("create", viewModel);
            }

            // Get Account
            var account = await _context.Accounts.FindAsync(viewModel.AccountNumber);

            // Create the withdrawal
            await account.StoreWithdrawal(_context, viewModel.Amount, viewModel.Comment);

            // Check if a surcharge needs to be applied
            int surchargeCheck = account.SurchargeCheck(_context, account.AccountNumber);

            // Apply surcharge if applicable 
            if (surchargeCheck > 2)
            {
                await account.StoreSurcharge(_context, _withdrawSurcharge);
            }

            // Success Flash Message
            TempData["Success"] = $"${viewModel.Amount} has been successfully withdrawn from {account.GetAccountType()}.";
            // Return to homepage
            return RedirectToAction("Index", "Home");
        }
    }
}
