﻿using Microsoft.AspNetCore.Mvc;
using MCBACustomerWebsite.Filters;
using MCBACustomerWebsite.Data;
using MCBACustomerWebsite.Utilities.Session;
using MCBACustomerWebsite.ViewModels;
using MCBACustomerWebsite.Validators;
using Microsoft.EntityFrameworkCore;
using MCBACustomerWebsite.Models;

namespace MCBACustomerWebsite.Controllers
{
    [AuthorizeCustomer]
    public class TransferController : Controller
    {

        private readonly McbaContext _context;

        public TransferController(McbaContext context) => _context = context;

        private int _customerID => HttpContext.Session.GetCustomerID().Value;

        private readonly decimal _transferSurcharge = 0.10m;


        public IActionResult Create()
        {
            var Accounts = _context.Accounts.Where(a => a.CustomerID == _customerID).ToList();

            return View("create", new TransferViewModel { Accounts = Accounts });
        }


        [HttpPost]
        public async Task<IActionResult> Confirm(TransferViewModel viewModel)
        {
            // Validate Form
            bool valid = ValidateTransfer.Validate(viewModel, ModelState, _context, _transferSurcharge);
            // If invalid return errors.
            if (!valid)
            {
                viewModel.Accounts = _context.Accounts.Where(a => a.CustomerID == _customerID).ToList();
                return View("create", viewModel);
            }


            return View("confirm", new TransferViewModel
            {
                AccountNumber = viewModel.AccountNumber,
                DestinationAccountNumber = viewModel.DestinationAccountNumber,
                Amount = viewModel.Amount,
                Comment = viewModel.Comment,
            });

        }


        [HttpPost]
        public async Task<IActionResult> Store(TransferViewModel viewModel)
        {
            // Validate Form
            bool valid = ValidateTransfer.Validate(viewModel, ModelState, _context, _transferSurcharge);
            // If invalid return errors.
            if (!valid)
            {
                viewModel.Accounts = _context.Accounts.Where(a => a.CustomerID == _customerID).ToList();
                return View("create", viewModel);
            }

            // Get Account
            Account account = _context.Accounts.Include(a => a.Transactions).FirstOrDefault(a => a.AccountNumber == viewModel.AccountNumber);

            // Get Destination Account
            Account destinationAccount = _context.Accounts.Include(a => a.Transactions).FirstOrDefault(a => a.AccountNumber == viewModel.DestinationAccountNumber);

            // Create the transfer
            await account.StoreOutgoingTransfer(_context, viewModel.Amount, viewModel.Comment, viewModel.DestinationAccountNumber);
            await destinationAccount.StoreTransferDeposit(_context, viewModel.Amount, viewModel.Comment);

            // Check if a surcharge needs to be applied
            int surchargeCheck = account.SurchargeCheck(_context, account.AccountNumber);

            // Apply surcharge if applicable 
            if (surchargeCheck > 2)
            {
                await account.StoreSurcharge(_context, _transferSurcharge);
            }

            // Success Flash Message
            TempData["Success"] = $"${viewModel.Amount} has been successfully transferred to {viewModel.DestinationAccountNumber} from {account.GetAccountType()}.";
            // Return to homepage
            return RedirectToAction("Index", "Home");
        }

    }
}
