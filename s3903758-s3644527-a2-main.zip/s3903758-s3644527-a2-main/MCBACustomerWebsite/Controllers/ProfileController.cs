﻿using MCBACustomerWebsite.Filters;
using Microsoft.AspNetCore.Mvc;
using MCBACustomerWebsite.ViewModels;
using MCBACustomerWebsite.Data;
using MCBACustomerWebsite.Utilities.Session;
using MCBACustomerWebsite.Models;
using MCBACustomerWebsite.Validators;
using System.IO;
using ImageMagick;
using System.Reflection;
using MCBACustomerWebsite.Utilities;
using Microsoft.Extensions.Hosting.Internal;
using System.Net;

namespace MCBACustomerWebsite.Controllers
{
    [AuthorizeCustomer]
    public class ProfileController : Controller
    {

        public ProfileController(McbaContext context) => _context = context;

        private readonly McbaContext _context;
        private int _customerID => HttpContext.Session.GetCustomerID().Value;

        public IActionResult Index()
        {

            Customer Customer = _context.Customers.Find(_customerID);

            return View("show", new ProfileIndexViewModel
            {
                Customer = Customer
            });
        }

        public IActionResult Edit()
        {

            Customer Customer = _context.Customers.Find(_customerID);

            return View("edit", new ProfileEditViewModel
            {
                Customer = Customer,
                StateOptions = Customer.StateMap,
            });
        }

        [HttpPost]
        public async Task<IActionResult> Update(ProfileEditViewModel viewModel)
        {
            // Get the logged in users Login from the database
            Customer Customer = _context.Customers.Find(_customerID);

            // Validate Form
            bool valid = ValidateProfileUpdate.Validate(viewModel, ModelState);
            // If invalid return errors.
            if (!valid)
            {
                viewModel.StateOptions = Customer.StateMap;
                viewModel.Customer = Customer;
                return View("edit", viewModel);
            }

            // Update the password
            await Customer.Update(_context, viewModel);


            // Success Flash Message
            TempData["Success"] = $"Your details have been successfully updated.";

            // Return to User Profile
            return RedirectToAction("index");

        }

        [HttpPost]
        public async Task<IActionResult> UpdatePassword(ProfileIndexViewModel viewModel)
        {
            // Get the logged in users Login from the database
            Login Login = _context.Logins.Where(a => a.CustomerID == _customerID).FirstOrDefault();

            // Validate Form
            bool valid = ValidatePasswordUpdate.Validate(viewModel, ModelState, Login);
            // If invalid return errors.
            if (!valid)
            {
                viewModel.Customer = _context.Customers.Find(_customerID);
                return View("show", viewModel);
            }

            // Update the password
            await Login.UpdatePassword(_context, viewModel.NewPassword);


            // Success Flash Message
            TempData["Success"] = $"Your password has been successfully updated.";

            // Return to User Profile
            return RedirectToAction("index");

        }

        [HttpPost]
        public async Task<RedirectToActionResult> UploadProfilePicture(IFormFile ProfilePicture)
        {

            // Still need to check if you can convert to jpg

            // Validate file is correct
            if (ProfilePicture == null || ProfilePicture.Length == 0 || !ProfilePicture.ContentType.StartsWith("image/"))
            {
                TempData["Error"] = "The file uploaded is not a valid image type.";
                return RedirectToAction("Index");
            }

            // Open memory stream
            using (var memoryStream = new MemoryStream())
            {
                // Read file to memory stream
                ProfilePicture.CopyTo(memoryStream);

                // Reset memory stream to beginning
                memoryStream.Seek(0, SeekOrigin.Begin);
                // Create new Magick Image
                using (var magickImage = new MagickImage(memoryStream))
                {



                    // Resize image proportional to max 400px either dimension and retain ratio
                    int TargetWidth = 400, TargetHeight = 400;
                    MagickGeometry resize_dimensions = ImageUtilities.CalculateResize(magickImage, TargetHeight, TargetWidth);
                    magickImage.Resize(resize_dimensions);
                    // Convert to Byte
                    byte[] imageData = magickImage.ToByteArray();
                    // Validate new File size
                    if (imageData.Length > 1048576)
                    {
                        TempData["Error"] = "This file size is too large.";
                        return RedirectToAction("Index");
                    }
                    // Get logged in customer and store new image to database
                    Customer Customer = _context.Customers.Find(_customerID);
                    Customer.ProfileImage = imageData;
                    await _context.SaveChangesAsync();

                }
            }

            // Return Success
            TempData["Success"] = "Image has successfully been saved.";
            return RedirectToAction("Index"); // Redirect to a relevant view

        }

        public async Task<IActionResult> DeleteProfilePicture()
        {

            Customer Customer = _context.Customers.Find(_customerID);

            if (Customer != null)
            {
                Customer.ProfileImage = null;
                await _context.SaveChangesAsync();
                TempData["Success"] = "Profile picture has successfully been deleted.";
            }

            // Return to User Profile
            return RedirectToAction("Index");

        }

        public FileContentResult GetProfileImage()
        {
            string contentType = "image/jpg";

            Customer Customer = _context.Customers.Find(_customerID);

            if(Customer.ProfileImage != null)
            {
                return File(Customer.ProfileImage, contentType);
            }


            byte[] defaultImageData;
            using (var webClient = new WebClient())
            {
                string defaultImageUrl = "https://webprojectuni.s3.ap-southeast-2.amazonaws.com/profile_placeholder.jpg";

                defaultImageData = webClient.DownloadData(defaultImageUrl);

            }


            // Return the default image data with the appropriate content type
            return File(defaultImageData, contentType);

        }

    }

}

